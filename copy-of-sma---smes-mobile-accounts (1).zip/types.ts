

export type Language = 'en' | 'ta';

export interface User {
  id: string;
  name: string;
  emailOrPhone: string;
  avatar?: string;
  type: 'GOOGLE' | 'MOBILE';
  position?: string; // Job title/Position
}

export type ActivityType = 'CALL' | 'UPDATE' | 'CREATE' | 'NOTE' | 'AI' | 'VOICE_UPDATE' | 'PAYMENT';

export type CallOutcome = 'CONNECTED' | 'DECLINED' | 'NO_ANSWER';

export interface ActivityLog {
  id: string;
  type: ActivityType;
  userId: string;
  userName: string;
  timestamp: string;
  details: string;
  callOutcome?: CallOutcome; // New field for smart call tracking
  audioUrl?: string; // New: Stores Base64 Data URI of voice recording
}

export interface CallRecord {
  id: string;
  date: string; // ISO Date string
  notes?: string;
}

export interface Customer {
  id: string;
  sNo?: string; // Serial Number from Excel
  name: string;
  phone: string;
  itemTaken: string;
  totalAmount: number;
  balance: number;
  date: string; // ISO Date string
  address: string;
  imageUrl?: string;
  location?: {
    lat: number;
    lng: number;
  };
  notes?: string;
  promisedPaymentDate?: string; // New: When customer promised to pay
  callHistory?: CallRecord[]; // Kept for backward compatibility
  activityLogs?: ActivityLog[]; // New: Full audit trail
}

export interface SheetMetadata {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  customerCount: number;
  totalBalance?: number; // New: Tracks total balance for the sheet
}

export type ViewState = 'LOGIN' | 'DASHBOARD' | 'LIST' | 'DETAIL' | 'IMPORT' | 'SHEET_MANAGER' | 'HISTORY' | 'ANALYTICS';

export interface DashboardStats {
  totalCustomers: number;
  totalBalance: number;
  recentCustomers: Customer[];
}

export interface BackupData {
  metadata: SheetMetadata[];
  sheets: Record<string, Customer[]>;
  version: number;
  timestamp: string;
}

export interface AppSettings {
  currencySymbol: string; // $, ₹, €, etc.
  currencyCode: string; // USD, INR, EUR
  conversionRate: number; // Multiplier for displayed values
  upiId?: string; // New: Merchant UPI ID for GPay
  merchantName?: string; // New: Merchant Name for GPay
  driveFolderLink?: string; // New: Link to shared Google Drive folder for Team Sync
  autoSyncEnabled?: boolean; // New: Toggle for auto-prompting sync
}

// New Interface for Sync Queue
export interface SyncItem {
  id: string;
  timestamp: string;
  actionType: string; // "Call Connected", "Payment Received", etc.
  description: string;
  userName: string;
}