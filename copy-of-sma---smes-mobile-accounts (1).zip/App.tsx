import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { CustomerDetail } from './components/CustomerDetail';
import { ImportWizard } from './components/ImportWizard';
import { SheetManager } from './components/SheetManager';
import { SettingsModal } from './components/SettingsModal';
import { LoginScreen } from './components/LoginScreen';
import { WorkHistory } from './components/WorkHistory';
import { SmartStatistics, StatsTab } from './components/SmartStatistics';
import { Customer, ViewState, Language, SheetMetadata, AppSettings, User } from './types';
import { 
  getSheetList, 
  loadSheetData, 
  createNewSheet, 
  saveSheetData, 
  deleteSheet 
} from './services/storageService';
import { getCurrentUser, logoutUser } from './services/authService';
import { translateCustomersToTamil } from './services/geminiService';
import { TRANSLATIONS } from './constants/translations';
import { Sparkles } from 'lucide-react';

const App: React.FC = () => {
  // Auth State
  const [user, setUser] = useState<User | null>(null);

  // Global State
  const [view, setView] = useState<ViewState | 'SETTINGS'>('LOGIN');
  const [language, setLanguage] = useState<Language>('en');
  const [isTranslating, setIsTranslating] = useState(false);
  const [translationProgress, setTranslationProgress] = useState(0);
  const [backgroundProcess, setBackgroundProcess] = useState<string | null>(null);
  const [analyticsTab, setAnalyticsTab] = useState<StatsTab>('CALLS');
  
  // Settings State (Defaults: INR, ₹ sign, 1:1 rate)
  const [settings, setSettings] = useState<AppSettings>({
    currencyCode: 'INR',
    currencySymbol: '₹',
    conversionRate: 1
  });

  // Sheet Management State
  const [sheets, setSheets] = useState<SheetMetadata[]>([]);
  const [activeSheetId, setActiveSheetId] = useState<string | null>(null);
  
  // Active Data State
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Load Translations
  const t = TRANSLATIONS[language];

  // 1. Initial Load & Auth Check
  useEffect(() => {
    const loggedInUser = getCurrentUser();
    if (loggedInUser) {
      setUser(loggedInUser);
      // Initialize History for Dashboard
      window.history.replaceState({ view: 'DASHBOARD' }, '', '');
      setView('DASHBOARD');
      refreshData();
    } else {
      window.history.replaceState({ view: 'LOGIN' }, '', '');
      setView('LOGIN');
    }
  }, []);

  // --- NAVIGATION HANDLER (Back Button Support) ---
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
       if (event.state && event.state.view) {
          setView(event.state.view);
          
          // Restore selected customer if returning to detail view from deeper state
          // Or clear it if returning to Dashboard
          if (event.state.view === 'DETAIL' && event.state.customerId) {
             const found = customers.find(c => c.id === event.state.customerId);
             if (found) setSelectedCustomer(found);
          } else if (event.state.view === 'DASHBOARD') {
             setSelectedCustomer(null);
          }
       } else {
          // Fallback if state is missing (e.g. external link entry)
          if (user) setView('DASHBOARD');
          else setView('LOGIN');
       }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [user, customers]); // Re-bind if user or data changes to ensure correct restoration

  // Helper to Push State
  const navigateTo = (newView: ViewState | 'SETTINGS', customerId?: string) => {
     window.history.pushState({ view: newView, customerId }, '', '');
     setView(newView);
  };

  // Helper to Go Back
  const navigateBack = () => {
     window.history.back();
  };

  const refreshData = () => {
    const sheetList = getSheetList();
    setSheets(sheetList);
    
    if (sheetList.length > 0 && !activeSheetId) {
      const firstSheet = sheetList[0];
      setActiveSheetId(firstSheet.id);
      setCustomers(loadSheetData(firstSheet.id));
    } else if (activeSheetId) {
      if (sheetList.find(s => s.id === activeSheetId)) {
        setCustomers(loadSheetData(activeSheetId));
      } else {
         setActiveSheetId(null);
         setCustomers([]);
      }
    } else {
      setCustomers([]);
    }
  };

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    // Replace login in history with Dashboard
    window.history.replaceState({ view: 'DASHBOARD' }, '', '');
    setView('DASHBOARD');
    setActiveSheetId(null);
    refreshData();
  };

  const handleLogout = () => {
    logoutUser();
    setUser(null);
    setCustomers([]);
    setSheets([]);
    setActiveSheetId(null);
    window.history.replaceState({ view: 'LOGIN' }, '', '');
    setView('LOGIN');
  };

  const handleSelectSheet = (sheetId: string) => {
    setActiveSheetId(sheetId);
    setCustomers(loadSheetData(sheetId));
    // View remains Dashboard, but data changes
  };

  const handleDeleteSheet = (sheetId: string) => {
    deleteSheet(sheetId);
    const updatedSheets = sheets.filter(s => s.id !== sheetId);
    setSheets(updatedSheets);
    
    if (activeSheetId === sheetId) {
      if (updatedSheets.length > 0) {
        handleSelectSheet(updatedSheets[0].id);
      } else {
        setActiveSheetId(null);
        setCustomers([]);
      }
    }
  };

  const handleImport = (newCustomers: Customer[], fileName: string) => {
    // 1. Check for Duplicate Name
    const duplicateName = sheets.find(s => s.name.toLowerCase().trim() === fileName.toLowerCase().trim());
    if (duplicateName) {
      alert(`🚫 Import Failed: Duplicate Name\n\nA sheet named "${fileName}" already exists.\nPlease rename your file or delete the existing sheet before importing.`);
      return;
    }

    // 2. Check for Duplicate Content (Smart Heuristic: Count & Balance match)
    const newTotal = newCustomers.reduce((acc, c) => acc + (c.balance || 0), 0);
    const newCount = newCustomers.length;
    
    const duplicateContent = sheets.find(s => 
       s.customerCount === newCount && 
       Math.abs((s.totalBalance || 0) - newTotal) < 0.5 // Tolerance for float diffs
    );

    if (duplicateContent) {
       // Strong warning / Soft block for similar content
       const msg = `⚠️ Possible Duplicate Data Detected\n\nThis file appears to be identical to existing sheet "${duplicateContent.name}" (Same customer count: ${newCount}, Same balance).\n\nDo you still want to import it as a separate sheet?`;
       if (!confirm(msg)) {
         return;
       }
    }

    try {
      const newSheetId = createNewSheet(fileName, newCustomers);
      const updatedList = getSheetList();
      setSheets(updatedList);
      setActiveSheetId(newSheetId);
      setCustomers(newCustomers);
      
      // Go back to Dashboard after import
      navigateBack(); 

    } catch (e) {
      console.error(e);
      alert("Error importing data");
    }
  };

  const handleTranslateSheet = async () => {
    if (!activeSheetId || customers.length === 0) return;

    setIsTranslating(true);
    setTranslationProgress(0);

    try {
      const translatedData = await translateCustomersToTamil(customers, (p) => setTranslationProgress(p));
      const activeSheet = sheets.find(s => s.id === activeSheetId);
      const newSheetName = `${activeSheet?.name || 'Data'} (Tamil)`;
      const newSheetId = createNewSheet(newSheetName, translatedData);
      
      setSheets(getSheetList());
      setActiveSheetId(newSheetId);
      setCustomers(translatedData);
      setLanguage('ta'); 
      
    } catch (error) {
      console.error(error);
      alert(t.translationError);
    } finally {
      setIsTranslating(false);
      setTranslationProgress(0);
    }
  };

  const handleUpdateCustomer = (updated: Customer) => {
    if (!activeSheetId) {
        const newId = createNewSheet("Default List", [updated]);
        setSheets(getSheetList());
        setActiveSheetId(newId);
        setCustomers([updated]);
        setSelectedCustomer(updated);
        // Note: New sheet created for single customer, staying on detail view
        return;
    }

    const toSave = updated.id ? updated : { ...updated, id: crypto.randomUUID() };
    
    let newCustomers;
    if (customers.find(c => c.id === toSave.id)) {
      newCustomers = customers.map(c => c.id === toSave.id ? toSave : c);
    } else {
      newCustomers = [toSave, ...customers];
    }
    
    setCustomers(newCustomers);
    saveSheetData(activeSheetId, newCustomers);
    setSheets(prev => prev.map(s => s.id === activeSheetId ? {...s, customerCount: newCustomers.length, updatedAt: new Date().toISOString()} : s));
    setSelectedCustomer(toSave);
  };

  const handleDeleteCustomer = (id: string) => {
    if (!activeSheetId) return;

    const updated = customers.filter(c => c.id !== id);
    setCustomers(updated);
    saveSheetData(activeSheetId, updated);
    setSheets(prev => prev.map(s => s.id === activeSheetId ? {...s, customerCount: updated.length, updatedAt: new Date().toISOString()} : s));

    setSelectedCustomer(null);
    navigateBack(); // Go back to Dashboard
  };

  const handleCustomerSelect = (c: Customer) => {
    setSelectedCustomer(c);
    navigateTo('DETAIL', c.id);
  };

  const handleAddNew = () => {
    const newC: Customer = {
      id: '',
      name: '',
      phone: '',
      itemTaken: '',
      totalAmount: 0,
      balance: 0,
      date: new Date().toISOString().split('T')[0],
      address: '',
    };
    setSelectedCustomer(newC);
    navigateTo('DETAIL');
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen shadow-2xl overflow-hidden relative">
      
      {backgroundProcess && (
         <div className="fixed bottom-4 right-4 left-4 z-[100] bg-gray-900 text-white p-3 rounded-lg shadow-xl flex items-center gap-3 animate-fade-in-up">
            <div className="animate-spin h-4 w-4 border-2 border-brand-500 border-t-transparent rounded-full"></div>
            <div className="text-xs font-medium flex-1">{backgroundProcess}</div>
         </div>
      )}

      {/* Settings Modal - Rendered globally */}
      <SettingsModal 
        isOpen={view === 'SETTINGS'} 
        onClose={() => navigateBack()}
        settings={settings}
        onSave={(newSettings) => setSettings(newSettings)}
        t={t}
      />

      {view === 'LOGIN' && (
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
      )}

      {view === 'DASHBOARD' && user && (
        <Dashboard 
          customers={customers}
          sheets={sheets}
          activeSheetId={activeSheetId}
          onSelectSheet={handleSelectSheet}
          onDeleteSheet={handleDeleteSheet}
          onSelectCustomer={handleCustomerSelect}
          onImportClick={() => navigateTo('IMPORT')}
          onAddNew={handleAddNew}
          onTranslateSheet={handleTranslateSheet}
          onOpenSheetManager={() => navigateTo('SHEET_MANAGER')}
          onOpenSettings={() => navigateTo('SETTINGS')}
          onOpenHistory={() => navigateTo('HISTORY')}
          onOpenAnalytics={() => { setAnalyticsTab('CALLS'); navigateTo('ANALYTICS'); }}
          onOpenTeamPerformance={() => { setAnalyticsTab('TEAM'); navigateTo('ANALYTICS'); }}
          onLogout={handleLogout}
          user={user}
          isTranslating={isTranslating}
          translationProgress={translationProgress}
          language={language}
          setLanguage={setLanguage}
          settings={settings}
          t={t}
        />
      )}

      {view === 'HISTORY' && (
        <WorkHistory 
          customers={customers} 
          onBack={() => navigateBack()}
          t={t}
        />
      )}

      {view === 'ANALYTICS' && (
        <SmartStatistics 
          customers={customers}
          onBack={() => navigateBack()}
          settings={settings}
          t={t}
          initialTab={analyticsTab}
        />
      )}

      {view === 'SHEET_MANAGER' && (
        <SheetManager 
          sheets={sheets}
          activeSheetId={activeSheetId}
          onSelectSheet={(id) => { handleSelectSheet(id); navigateBack(); }}
          onDeleteSheet={handleDeleteSheet}
          onClose={() => navigateBack()}
          onRefresh={refreshData}
          t={t}
        />
      )}

      {view === 'IMPORT' && (
        <div className="min-h-screen bg-gray-50 p-4 pt-10">
          <ImportWizard 
            onImport={handleImport} 
            onCancel={() => navigateBack()} 
            t={t}
          />
        </div>
      )}

      {view === 'DETAIL' && selectedCustomer && user && (
        <CustomerDetail 
          customer={selectedCustomer}
          onBack={() => navigateBack()}
          onUpdate={handleUpdateCustomer}
          onDelete={handleDeleteCustomer}
          language={language}
          settings={settings}
          user={user}
          t={t}
        />
      )}
    </div>
  );
};

export default App;