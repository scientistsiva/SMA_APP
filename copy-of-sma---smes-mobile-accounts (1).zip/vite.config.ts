import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // This ensures assets are loaded relatively (./) instead of absolutely (/)
  // Essential for GitHub Pages and hosting on Google Drive folders
  base: './', 
  define: {
    // Defines process.env for the GemniService which checks process.env.API_KEY
    'process.env': process.env
  },
  build: {
    // Changing output directory to match your Render "Publish Directory" setting
    outDir: 'smes_official_website',
    sourcemap: false
  }
});