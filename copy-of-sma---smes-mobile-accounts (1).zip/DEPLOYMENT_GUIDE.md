# 🚀 Easy GitHub Guide for SMES App

We have created automatic scripts to make GitHub easy. You do not need to type commands manually.

## 🟢 Step 1: First Time Setup
1. Create a new repository on [GitHub.com](https://github.com/new).
2. Copy the **HTTPS URL** (e.g., `https://github.com/username/repo.git`).
3. Double