import { User } from '../types';
import { auth } from '../firebaseConfig';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  RecaptchaVerifier, 
  signInWithPhoneNumber, 
  ConfirmationResult,
  signOut
} from 'firebase/auth';

const USER_KEY = 'SMA_CURRENT_USER';
const USERS_DB_KEY = 'SMA_USERS_DB'; 

// --- Helper for Mock DB (We still keep local user metadata for this simple demo) ---
// In a full implementation, this metadata would be stored in Firestore 'users' collection
const getUsersDb = (): Record<string, User> => {
  try {
    const json = localStorage.getItem(USERS_DB_KEY);
    return json ? JSON.parse(json) : {};
  } catch {
    return {};
  }
};

const saveUserToDb = (user: User) => {
  const db = getUsersDb();
  // Normalize phone key
  const key = user.emailOrPhone.replace(/\D/g, '');
  if (key) {
    db[key] = user;
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(db));
  }
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(USER_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
    localStorage.removeItem(USER_KEY);
  } catch (error) {
    console.error("Logout failed", error);
  }
};

// --- Google Login (Real) ---
export const loginWithGoogle = async (): Promise<User | null> => {
  try {
    const provider = new GoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    const appUser: User = {
      id: user.uid,
      name: user.displayName || 'Google User',
      emailOrPhone: user.email || '',
      avatar: user.photoURL || undefined,
      type: 'GOOGLE',
      position: 'Staff'
    };

    localStorage.setItem(USER_KEY, JSON.stringify(appUser));
    return appUser;
  } catch (error) {
    console.error("Google Auth Error:", error);
    throw error;
  }
};

// --- Mobile OTP Flow (Real Firebase) ---

export const setupRecaptcha = async (phoneNumber: string) => {
  if (!window.recaptchaVerifier) {
    window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      'size': 'invisible',
      'callback': () => {
        // reCAPTCHA solved, allow signInWithPhoneNumber.
      }
    });
  }
  
  const appVerifier = window.recaptchaVerifier;
  try {
    // Send the OTP
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
    return confirmationResult; // We return this to the UI to handle the verification step
  } catch (error) {
    console.error("SMS Error:", error);
    // Reset recaptcha on error so user can try again
    if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear();
        // @ts-ignore
        window.recaptchaVerifier = null;
    }
    throw error;
  }
};

// This replaces the old verifyOtp
export const verifyFirebaseOtp = async (
  confirmationResult: ConfirmationResult, 
  otp: string, 
  name?: string,
  position?: string,
  avatar?: string
): Promise<User | null> => {
  try {
    const result = await confirmationResult.confirm(otp);
    const user = result.user;
    
    // Logic to persist user metadata locally (or in Firestore in future)
    const cleanPhone = user.phoneNumber?.replace(/\D/g, '') || '';
    const db = getUsersDb();
    let existingUser = db[cleanPhone];

    // Determine Name
    const displayName = name && name.trim().length > 0 
       ? name 
       : (existingUser ? existingUser.name : `Staff ${cleanPhone.slice(-4)}`);

    const appUser: User = {
      id: user.uid,
      name: displayName,
      emailOrPhone: user.phoneNumber || '',
      type: 'MOBILE',
      position: position || (existingUser ? existingUser.position : 'Staff'),
      avatar: avatar || existingUser?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=10b981&color=fff`
    };

    saveUserToDb(appUser);
    localStorage.setItem(USER_KEY, JSON.stringify(appUser));
    return appUser;

  } catch (error) {
    console.error("OTP Verification Error:", error);
    throw error;
  }
};

// Legacy stub needed for type compatibility if any other file imports it directly,
// but UI now uses setupRecaptcha directly
export const sendOtp = async (phoneNumber: string): Promise<string> => {
   throw new Error("Use setupRecaptcha instead for Firebase");
};

// Kept for signature compatibility but essentially aliases verifyFirebaseOtp logic
export const verifyOtp = async (phoneNumber: string, otp: string, name?: string): Promise<User | null> => {
   throw new Error("Use verifyFirebaseOtp instead for Firebase");
};

export const registerUser = async (): Promise<User | null> => {
   throw new Error("Use verifyFirebaseOtp instead for Firebase");
};