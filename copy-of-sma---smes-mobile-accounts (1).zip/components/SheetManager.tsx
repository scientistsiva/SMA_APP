import React, { useRef } from 'react';
import { 
  FileText, Trash2, ArrowRight, Calendar, Users, 
  ArrowLeft, FolderOpen, Languages, Cloud, UploadCloud, Clock, DownloadCloud
} from 'lucide-react';
import { SheetMetadata } from '../types';
import { TranslationKeys } from '../constants/translations';
import { generateBackup, restoreFromBackup } from '../services/storageService';

interface SheetManagerProps {
  sheets: SheetMetadata[];
  activeSheetId: string | null;
  onSelectSheet: (id: string) => void;
  onDeleteSheet: (id: string) => void;
  onClose: () => void;
  onRefresh: () => void; // To reload data after restore
  t: TranslationKeys;
}

export const SheetManager: React.FC<SheetManagerProps> = ({ 
  sheets, 
  activeSheetId, 
  onSelectSheet, 
  onDeleteSheet, 
  onClose,
  onRefresh,
  t 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sort sheets: Newest updated first
  const sortedSheets = [...sheets].sort((a, b) => 
    new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime()
  );

  const handleCloudBackup = async () => {
    const backupBlob = generateBackup();
    const fileName = `SMA_Backup_${new Date().toISOString().slice(0,10)}.json`;
    const file = new File([backupBlob], fileName, { type: 'application/json' });

    // Use Web Share API if available (Mobile)
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: 'SMA Backup',
          text: t.backupDesc,
        });
      } catch (error) {
        console.error("Share failed", error);
      }
    } else {
      // Fallback to Download (Desktop)
      const url = URL.createObjectURL(backupBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      alert(t.backupSuccess);
    }
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      try {
        await restoreFromBackup(file);
        alert(t.restoreSuccess);
        onRefresh();
      } catch (error) {
        alert(t.restoreError);
      }
      // Reset input
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-10">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b shadow-sm px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button 
            onClick={onClose} 
            className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <FolderOpen className="text-brand-600" />
            {t.savedAccounts}
          </h1>
        </div>
      </div>

      <div className="p-4 space-y-6">
        
        {/* Cloud Actions Card */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-start justify-between mb-4">
             <div>
               <h3 className="font-bold text-lg flex items-center gap-2">
                 <Cloud size={20} className="text-blue-200" /> Cloud Sync
               </h3>
               <p className="text-blue-100 text-xs mt-1">
                 Permanent storage via Google Drive / OneDrive
               </p>
             </div>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={handleCloudBackup}
              className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm py-3 rounded-xl font-semibold text-sm flex flex-col items-center gap-1 transition-colors border border-white/10"
            >
              <UploadCloud size={20} />
              {t.cloudBackup}
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm py-3 rounded-xl font-semibold text-sm flex flex-col items-center gap-1 transition-colors border border-white/10"
            >
              <DownloadCloud size={20} />
              {t.restoreBackup}
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".json" 
              onChange={handleRestore}
            />
          </div>
        </div>

        {/* Sheet List */}
        <div>
          <h2 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">{t.sheets} ({sortedSheets.length})</h2>
          
          {sortedSheets.length === 0 ? (
            <div className="flex flex-col items-center justify-center mt-10 text-gray-400">
               <FolderOpen size={64} className="mb-4 opacity-30" />
               <p className="text-lg font-medium">{t.noSheets}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedSheets.map((sheet) => {
                const isTamil = sheet.name.toLowerCase().includes('tamil');
                const isActive = sheet.id === activeSheetId;
                const updatedDate = new Date(sheet.updatedAt || sheet.createdAt);

                return (
                  <div 
                    key={sheet.id}
                    onClick={() => onSelectSheet(sheet.id)}
                    className={`relative group bg-white rounded-xl p-4 border transition-all cursor-pointer shadow-sm hover:shadow-md ${
                      isActive ? 'border-brand-500 ring-1 ring-brand-100' : 'border-gray-200 hover:border-brand-300'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-3">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${
                          isTamil ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                           {isTamil ? <Languages size={24} /> : <FileText size={24} />}
                        </div>
                        
                        <div>
                          <h3 className="font-bold text-gray-900 line-clamp-1">{sheet.name}</h3>
                          
                          <div className="flex flex-col gap-1 mt-1">
                             <div className="flex items-center gap-3 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <Users size={12} /> {sheet.customerCount}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar size={12} /> {new Date(sheet.createdAt).toLocaleDateString()}
                                </span>
                             </div>
                             <div className="flex items-center gap-1 text-[10px] text-gray-400 font-medium">
                                <Clock size={10} /> 
                                {t.lastUpdated}: {updatedDate.toLocaleDateString()} {updatedDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                             </div>
                          </div>

                          <span className={`inline-block mt-2 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide ${
                              isTamil ? 'bg-purple-50 text-purple-700 border border-purple-100' : 'bg-blue-50 text-blue-700 border border-blue-100'
                          }`}>
                            {isTamil ? t.tamilVersion : t.englishVersion}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2">
                         {isActive && (
                           <span className="bg-brand-500 text-white text-[10px] font-bold px-2 py-1 rounded-full text-center">
                             Active
                           </span>
                         )}
                      </div>
                    </div>

                    {/* Actions Layer */}
                    <div className="absolute right-4 bottom-4 flex gap-2">
                      <button 
                        onClick={(e) => {
                           e.stopPropagation();
                           if(confirm(t.confirmDeleteSheet)) onDeleteSheet(sheet.id);
                        }}
                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                        title={t.deleteSheet}
                      >
                        <Trash2 size={18} />
                      </button>
                      <button 
                         className="p-2 text-brand-600 hover:bg-brand-50 rounded-full transition-colors"
                      >
                         <ArrowRight size={20} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};