import React, { useState } from 'react';
import { X, Settings as SettingsIcon, RefreshCw, DollarSign, IndianRupee, Euro, PoundSterling, JapaneseYen, CreditCard, Cloud, Link } from 'lucide-react';
import { AppSettings } from '../types';
import { TranslationKeys } from '../constants/translations';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
  t: TranslationKeys;
}

const SUPPORTED_CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar', icon: DollarSign },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', icon: IndianRupee },
  { code: 'EUR', symbol: '€', name: 'Euro', icon: Euro },
  { code: 'GBP', symbol: '£', name: 'British Pound', icon: PoundSterling },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', icon: JapaneseYen },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, onClose, settings, onSave, t 
}) => {
  const [baseCode, setBaseCode] = useState('USD');
  const [targetCode, setTargetCode] = useState(settings.currencyCode);
  const [targetSymbol, setTargetSymbol] = useState(settings.currencySymbol);
  const [rate, setRate] = useState(settings.conversionRate);
  
  // Payment Settings State
  const [upiId, setUpiId] = useState(settings.upiId || '');
  const [merchantName, setMerchantName] = useState(settings.merchantName || 'SMES');

  // Sync Settings
  const [driveLink, setDriveLink] = useState(settings.driveFolderLink || '');
  const [autoSync, setAutoSync] = useState(settings.autoSyncEnabled || false);
  
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const fetchRates = async () => {
    setLoading(true);
    try {
      // Free API for exchange rates
      const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${baseCode}`);
      const data = await res.json();
      const newRate = data.rates[targetCode];
      if (newRate) {
        setRate(newRate);
      } else {
        alert(t.rateError);
      }
    } catch (e) {
      console.error(e);
      alert(t.rateError);
    } finally {
      setLoading(false);
    }
  };

  const handleTargetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const code = e.target.value;
    const currency = SUPPORTED_CURRENCIES.find(c => c.code === code);
    setTargetCode(code);
    if (currency) setTargetSymbol(currency.symbol);
  };

  const handleSave = () => {
    onSave({
      currencyCode: targetCode,
      currencySymbol: targetSymbol,
      conversionRate: rate,
      upiId: upiId,
      merchantName: merchantName,
      driveFolderLink: driveLink,
      autoSyncEnabled: autoSync
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-scale-in max-h-[90vh] overflow-y-auto">
        <div className="bg-brand-50 p-4 border-b flex justify-between items-center sticky top-0 bg-white/95 backdrop-blur z-10">
          <h2 className="font-bold text-lg text-brand-900 flex items-center gap-2">
            <SettingsIcon size={20} /> {t.settings}
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-brand-100 text-gray-500">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
           {/* Section: Cloud Sync */}
           <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100">
            <h3 className="text-sm font-bold text-blue-800 uppercase tracking-wide mb-4 flex items-center gap-2">
              <Cloud size={16} /> Team Sync Settings
            </h3>
            
            <div className="space-y-4">
               <div>
                 <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                   <Link size={12} /> Google Drive Folder Link
                 </label>
                 <input 
                   type="text" 
                   value={driveLink} 
                   onChange={(e) => setDriveLink(e.target.value)}
                   placeholder="https://drive.google.com/drive/folders/..."
                   className="w-full p-2 border rounded-lg text-sm bg-white"
                 />
                 <p className="text-[10px] text-gray-500 mt-1">Paste the link to your team's shared folder here.</p>
               </div>
               
               <div className="flex items-center gap-3">
                 <input 
                   type="checkbox" 
                   id="autoSync"
                   checked={autoSync}
                   onChange={(e) => setAutoSync(e.target.checked)}
                   className="w-4 h-4 text-blue-600 rounded"
                 />
                 <label htmlFor="autoSync" className="text-sm font-bold text-gray-700">Enable Smart Auto-Sync</label>
               </div>
               <p className="text-[10px] text-gray-500 ml-7">If enabled, app will remind you to sync after every 5 actions.</p>
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* Section: Payment Settings */}
          <div className="bg-green-50/50 p-4 rounded-xl border border-green-100">
            <h3 className="text-sm font-bold text-green-800 uppercase tracking-wide mb-4 flex items-center gap-2">
              <CreditCard size={16} /> {t.merchantSettings}
            </h3>
            
            <div className="space-y-4">
               <div>
                 <label className="block text-xs font-bold text-gray-700 mb-1">{t.upiId}</label>
                 <input 
                   type="text" 
                   value={upiId} 
                   onChange={(e) => setUpiId(e.target.value)}
                   placeholder="e.g. smes@okhdfcbank"
                   className="w-full p-2 border rounded-lg text-sm bg-white"
                 />
                 <p className="text-[10px] text-gray-500 mt-1">Required for G-Pay Scanner</p>
               </div>
               <div>
                 <label className="block text-xs font-bold text-gray-700 mb-1">{t.merchantName}</label>
                 <input 
                   type="text" 
                   value={merchantName} 
                   onChange={(e) => setMerchantName(e.target.value)}
                   placeholder="e.g. SMES Olagadam"
                   className="w-full p-2 border rounded-lg text-sm bg-white"
                 />
               </div>
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* Section: Currency Config */}
          <div>
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-4">
              {t.currencySettings}
            </h3>

            <div className="grid grid-cols-2 gap-4 mb-4">
               <div>
                 <label className="block text-xs font-bold text-gray-700 mb-1">{t.baseCurrency}</label>
                 <select 
                   value={baseCode}
                   onChange={(e) => setBaseCode(e.target.value)}
                   className="w-full p-2 border rounded-lg bg-gray-50 text-sm"
                 >
                   {SUPPORTED_CURRENCIES.map(c => (
                     <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                   ))}
                 </select>
               </div>
               <div>
                 <label className="block text-xs font-bold text-gray-700 mb-1">{t.displayCurrency}</label>
                 <select 
                   value={targetCode}
                   onChange={handleTargetChange}
                   className="w-full p-2 border rounded-lg bg-gray-50 text-sm"
                 >
                   {SUPPORTED_CURRENCIES.map(c => (
                     <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                   ))}
                 </select>
               </div>
            </div>

            <div className="mb-4">
               <label className="block text-xs font-bold text-gray-700 mb-1">{t.rate} (Multiplier)</label>
               <div className="flex gap-2">
                 <input 
                   type="number" 
                   value={rate} 
                   onChange={(e) => setRate(parseFloat(e.target.value))}
                   className="flex-1 p-2 border rounded-lg text-sm"
                   step="0.01"
                 />
                 <button 
                   onClick={fetchRates}
                   disabled={loading}
                   className="bg-brand-100 text-brand-700 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-brand-200"
                 >
                   {loading ? (
                     <span className="animate-spin h-3 w-3 border-2 border-current border-t-transparent rounded-full" />
                   ) : (
                     <RefreshCw size={14} />
                   )}
                   {loading ? t.fetching : t.fetchRates}
                 </button>
               </div>
            </div>

            <div className="bg-gray-50 p-3 rounded-xl border border-gray-200">
               <span className="text-xs text-gray-500 font-bold uppercase">{t.preview}:</span>
               <div className="flex justify-between items-center mt-1">
                 <span className="text-sm text-gray-600">1000 Units</span>
                 <ArrowRight />
                 <span className="text-lg font-bold text-brand-600">
                    {targetSymbol}{(1000 * rate).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                 </span>
               </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t bg-gray-50 sticky bottom-0">
          <button 
            onClick={handleSave}
            className="w-full bg-brand-600 text-white py-3 rounded-xl font-bold hover:bg-brand-700 shadow-md"
          >
            {t.apply}
          </button>
        </div>
      </div>
    </div>
  );
};

const ArrowRight = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400">
    <path d="M5 12h14" />
    <path d="m12 5 7 7-7 7" />
  </svg>
);