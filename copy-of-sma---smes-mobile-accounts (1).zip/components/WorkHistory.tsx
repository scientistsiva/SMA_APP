import React, { useMemo, useState } from 'react';
import { ArrowLeft, History, Phone, Edit3, MessageSquare, Sparkles, CheckCircle, Search, User, Calendar, Filter, PhoneIncoming, PhoneOff, PhoneMissed, Mic, Wallet, ArrowDownCircle } from 'lucide-react';
import { Customer, ActivityLog } from '../types';
import { TranslationKeys } from '../constants/translations';

interface WorkHistoryProps {
  customers: Customer[];
  onBack: () => void;
  t: TranslationKeys;
}

// Extend ActivityLog to include context about which customer it belongs to
interface EnrichedLog extends ActivityLog {
  customerName: string;
  customerPhone: string;
}

export const WorkHistory: React.FC<WorkHistoryProps> = ({ customers, onBack, t }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const allActivities = useMemo(() => {
    const logs: EnrichedLog[] = [];
    
    customers.forEach(c => {
      // 1. Process Modern Activity Logs
      if (c.activityLogs) {
        c.activityLogs.forEach(log => {
          logs.push({ 
            ...log, 
            customerName: c.name,
            customerPhone: c.phone
          });
        });
      }
      
      // 2. Process Legacy Call History (for backward compatibility)
      if (c.callHistory) {
        c.callHistory.forEach(call => {
          // Check if this legacy call is already in activityLogs (simple deduplication by timestamp)
          const exists = c.activityLogs?.some(al => al.timestamp === call.date && al.type === 'CALL');
          
          if (!exists) {
            logs.push({
              id: call.id,
              type: 'CALL',
              userId: 'legacy',
              userName: 'System',
              timestamp: call.date,
              details: call.notes || 'Outgoing Call',
              customerName: c.name,
              customerPhone: c.phone,
              callOutcome: 'CONNECTED' // Assume legacy is connected
            });
          }
        });
      }
    });

    // Sort by Date Descending (Newest First)
    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [customers]);

  const filteredActivities = useMemo(() => {
     return allActivities.filter(log => 
       log.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
       log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
       log.details.toLowerCase().includes(searchTerm.toLowerCase())
     );
  }, [allActivities, searchTerm]);

  return (
    <div className="bg-gray-50 min-h-screen pb-10">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b shadow-sm px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack} 
            className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <History className="text-brand-600" />
            {t.workHistory}
          </h1>
        </div>
        <div className="bg-brand-100 text-brand-700 text-xs font-bold px-3 py-1 rounded-full">
           {filteredActivities.length} Actions
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-4 bg-white border-b border-gray-100">
        <div className="relative">
            <Search className="absolute left-3 top-3 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search user, customer or action..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none text-sm"
            />
        </div>
      </div>

      {/* Timeline List */}
      <div className="p-4">
        {filteredActivities.length === 0 ? (
          <div className="flex flex-col items-center justify-center mt-20 text-gray-400">
             <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <History size={32} className="opacity-30" />
             </div>
             <p className="font-medium">{t.noActivity}</p>
          </div>
        ) : (
          <div className="space-y-6">
             {filteredActivities.map((log, index) => {
               const date = new Date(log.timestamp);
               const isNewDay = index === 0 || new Date(filteredActivities[index - 1].timestamp).toDateString() !== date.toDateString();

               // Determine Style
               let icon = <CheckCircle size={18} />;
               let colorClass = 'bg-gray-50 text-gray-500';

               if (log.type === 'CALL') {
                   if (log.callOutcome === 'CONNECTED' || !log.callOutcome) {
                       icon = <PhoneIncoming size={18} />;
                       colorClass = 'bg-green-50 text-green-600';
                   } else if (log.callOutcome === 'DECLINED') {
                       icon = <PhoneOff size={18} />;
                       colorClass = 'bg-red-50 text-red-600';
                   } else if (log.callOutcome === 'NO_ANSWER') {
                       icon = <PhoneMissed size={18} />;
                       colorClass = 'bg-orange-50 text-orange-600';
                   }
               } else if (log.type === 'PAYMENT') {
                   icon = <Wallet size={18} />;
                   colorClass = 'bg-emerald-100 text-emerald-700 border-emerald-200';
               } else if (log.type === 'UPDATE') {
                   icon = <Edit3 size={18} />;
                   colorClass = 'bg-blue-50 text-blue-600';
               } else if (log.type === 'VOICE_UPDATE') {
                   icon = <Mic size={18} />;
                   colorClass = 'bg-pink-50 text-pink-600';
               } else if (log.type === 'AI') {
                   icon = <Sparkles size={18} />;
                   colorClass = 'bg-purple-50 text-purple-600';
               } else if (log.type === 'NOTE') {
                   icon = <MessageSquare size={18} />;
                   colorClass = 'bg-yellow-50 text-yellow-600';
               }

               return (
                 <div key={log.id}>
                    {/* Date Header */}
                    {isNewDay && (
                      <div className="flex items-center gap-2 mb-4 mt-2">
                         <Calendar size={14} className="text-gray-400" />
                         <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                           {date.toLocaleDateString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' })}
                         </span>
                         <div className="h-px bg-gray-200 flex-1"></div>
                      </div>
                    )}

                    {/* Activity Item */}
                    <div className="relative pl-6 pb-2 group">
                       {/* Timeline Line */}
                       <div className="absolute left-[11px] top-6 bottom-[-24px] w-[2px] bg-gray-100 group-last:hidden"></div>
                       
                       {/* Action Card */}
                       <div className={`bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow 
                          ${log.callOutcome === 'DECLINED' ? 'border-l-4 border-l-red-400' : ''} 
                          ${log.callOutcome === 'CONNECTED' ? 'border-l-4 border-l-green-400' : ''}
                          ${log.type === 'PAYMENT' ? 'border-l-4 border-l-emerald-500 bg-emerald-50/30' : ''}
                       `}>
                          <div className="flex justify-between items-start mb-2">
                             <div className="flex items-center gap-2">
                                {/* User Avatar */}
                                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600 border border-white shadow-sm ring-1 ring-slate-50">
                                   {log.userName.charAt(0).toUpperCase()}
                                </div>
                                <span className="text-xs font-bold text-slate-700">{log.userName}</span>
                             </div>
                             <span className="text-[10px] text-gray-400 font-mono">
                               {date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                             </span>
                          </div>

                          <div className="flex gap-3">
                             {/* Icon Box */}
                             <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${colorClass}`}>
                                {icon}
                             </div>

                             <div className="flex-1">
                                <p className="text-sm text-gray-800 font-medium leading-snug">
                                   {log.details}
                                </p>
                                
                                {/* Audio Player */}
                                {log.audioUrl && (
                                   <div className="mt-2 bg-gray-50 p-2 rounded-lg border border-gray-100">
                                      <div className="text-[10px] text-gray-400 mb-1 font-bold uppercase tracking-wider flex items-center gap-1">
                                         <Mic size={10} /> Voice Recording
                                      </div>
                                      <audio controls src={log.audioUrl} className="w-full h-8" />
                                   </div>
                                )}

                                <div className="mt-1.5 flex items-center gap-1 text-xs text-gray-500 bg-gray-50 inline-block px-2 py-1 rounded-md">
                                   <User size={10} /> 
                                   <span className="opacity-70">{t.forCustomer}:</span> 
                                   <span className="font-semibold text-gray-700">{log.customerName}</span>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
               );
             })}
          </div>
        )}
      </div>
    </div>
  );
};