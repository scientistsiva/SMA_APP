import React, { useState, useEffect } from 'react';
import { Mail, Smartphone, ArrowRight, ShieldCheck, Lock, UserPlus, User, Briefcase, Building2, CheckSquare, Camera, X, AlertTriangle } from 'lucide-react';
import { loginWithGoogle, setupRecaptcha, verifyFirebaseOtp, registerUser } from '../services/authService';
import { isConfigured } from '../firebaseConfig';
import { User as AppUser } from '../types';
import { RecaptchaVerifier, SignInMethod } from 'firebase/auth';

interface LoginScreenProps {
  onLoginSuccess: (user: AppUser) => void;
}

// Declare window type for recaptcha
declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier;
  }
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [viewMode, setViewMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  
  // Login State
  const [method, setMethod] = useState<'GOOGLE' | 'MOBILE'>('GOOGLE');
  const [loginName, setLoginName] = useState(''); 
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'PHONE' | 'OTP'>('PHONE');
  
  // Firebase Confirmation Object
  const [confirmObj, setConfirmObj] = useState<any>(null);
  
  // Registration State
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPosition, setRegPosition] = useState('');
  const [regBranchConfirmed, setRegBranchConfirmed] = useState(false);
  const [regOtp, setRegOtp] = useState('');
  const [regImage, setRegImage] = useState<string | null>(null); 
  const [regStep, setRegStep] = useState<'DETAILS' | 'OTP'>('DETAILS');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [configError, setConfigError] = useState(false);

  useEffect(() => {
     if (!isConfigured()) {
        setConfigError(true);
     }
  }, []);

  const handleGoogleLogin = async () => {
    if (configError) {
      setError("App not configured. See warning above.");
      return;
    }
    setLoading(true);
    try {
      const user = await loginWithGoogle();
      if (user) onLoginSuccess(user);
    } catch (e: any) {
      console.error(e);
      // specific error for domain issues
      if (e.code === 'auth/unauthorized-domain') {
        setError('Domain not authorized in Firebase Console. Please add this website to Authorized Domains.');
      } else if (e.code === 'auth/popup-closed-by-user') {
        setError('Sign-in cancelled.');
      } else {
        setError(e.message || 'Google Sign-In failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  // --- Login Logic ---
  const handleSendLoginOtp = async () => {
    if (configError) {
      setError("App not configured.");
      return;
    }
    if (phone.length < 10) {
      setError('Please enter a valid mobile number');
      return;
    }
    setLoading(true);
    setError('');
    
    // Format phone for Firebase (+91 default)
    const formattedPhone = phone.startsWith('+') ? phone : `+91${phone}`;

    try {
      // Setup Recaptcha
      const response = await setupRecaptcha(formattedPhone);
      setConfirmObj(response);
      setStep('OTP');
    } catch (e: any) {
      console.error(e);
      if (e.code === 'auth/invalid-app-credential') {
         setError('Firebase setup error. Check console.');
      } else {
         setError(e.message || 'Failed to send OTP. Check Recaptcha.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyLoginOtp = async () => {
    if (otp.length < 6) {
      setError('Enter valid 6-digit OTP');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const user = await verifyFirebaseOtp(confirmObj, otp, loginName);
      if (user) onLoginSuccess(user);
    } catch (e: any) {
      setError('Invalid OTP or verification failed.');
    } finally {
      setLoading(false);
    }
  };

  // --- Registration Logic ---
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("Image size too large (Max 5MB)");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setRegImage(result);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendRegisterOtp = async () => {
    if (configError) return;

    if (!regName.trim() || !regPosition.trim()) {
      setError('Please fill in Name and Position.');
      return;
    }
    if (regPhone.length < 10) {
      setError('Please enter a valid mobile number.');
      return;
    }
    if (!regBranchConfirmed) {
      setError('You must confirm your branch.');
      return;
    }

    setLoading(true);
    setError('');
    
    const formattedPhone = regPhone.startsWith('+') ? regPhone : `+91${regPhone}`;

    try {
      const response = await setupRecaptcha(formattedPhone);
      setConfirmObj(response);
      setRegStep('OTP');
    } catch (e: any) {
      console.error(e);
      setError('Failed to send OTP. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteRegistration = async () => {
    if (regOtp.length < 6) {
      setError('Enter valid 6-digit OTP');
      return;
    }
    setLoading(true);
    setError('');
    try {
      // First verify OTP via Firebase
      const user = await verifyFirebaseOtp(confirmObj, regOtp, regName, regPosition, regImage || undefined);
      if (user) onLoginSuccess(user);
    } catch (e) {
      setError('Invalid OTP.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-600 to-brand-800 flex flex-col items-center justify-center p-6 text-white overflow-y-auto">
      
      {/* Hidden container for Firebase Recaptcha */}
      <div id="recaptcha-container"></div>

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden text-gray-800 animate-scale-in my-8 relative">
        
        {configError && (
           <div className="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 m-4 mb-0 rounded-r shadow-sm">
              <div className="flex items-center gap-2 font-bold text-sm">
                 <AlertTriangle size={18} /> Configuration Required
              </div>
              <p className="text-xs mt-1">
                 Please update <code>firebaseConfig.ts</code> with your actual Firebase API keys. The current keys are placeholders, so login will not work.
              </p>
           </div>
        )}

        {/* Header */}
        <div className={`p-8 text-center border-b ${viewMode === 'REGISTER' ? 'bg-green-50 border-green-100' : 'bg-brand-50 border-brand-100'}`}>
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm ${viewMode === 'REGISTER' ? 'bg-green-100 text-green-600' : 'bg-brand-100 text-brand-600'}`}>
            {viewMode === 'REGISTER' ? <UserPlus size={32} /> : <Lock size={32} />}
          </div>
          <h1 className={`text-2xl font-bold ${viewMode === 'REGISTER' ? 'text-green-900' : 'text-brand-900'}`}>
            {viewMode === 'REGISTER' ? 'Staff Registration' : 'Welcome to SMA'}
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            {viewMode === 'REGISTER' ? 'Create your official account' : 'Secure Mobile Accounts'}
          </p>
        </div>

        {/* --- VIEW: LOGIN --- */}
        {viewMode === 'LOGIN' && (
          <>
            {/* Tabs */}
            <div className="flex border-b border-gray-100">
              <button 
                onClick={() => setMethod('GOOGLE')}
                className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors ${method === 'GOOGLE' ? 'text-brand-600 border-b-2 border-brand-600 bg-brand-50/50' : 'text-gray-400 hover:bg-gray-50'}`}
              >
                <Mail size={18} /> Google
              </button>
              <button 
                onClick={() => setMethod('MOBILE')}
                className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors ${method === 'MOBILE' ? 'text-brand-600 border-b-2 border-brand-600 bg-brand-50/50' : 'text-gray-400 hover:bg-gray-50'}`}
              >
                <Smartphone size={18} /> Mobile
              </button>
            </div>

            <div className="p-8 flex flex-col justify-center">
              {method === 'GOOGLE' ? (
                <div className="text-center space-y-6 animate-fade-in">
                  <p className="text-gray-500 text-sm">Sign in with your SMES corporate account.</p>
                  
                  <button 
                    onClick={handleGoogleLogin}
                    disabled={loading}
                    className="w-full bg-white border border-gray-300 text-gray-700 py-4 rounded-xl font-bold hover:bg-gray-50 hover:shadow-md transition-all flex items-center justify-center gap-3 relative overflow-hidden"
                  >
                    {loading && (
                       <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
                         <span className="animate-spin h-5 w-5 border-2 border-brand-500 border-t-transparent rounded-full"></span>
                       </div>
                    )}
                    <img src="https://www.google.com/favicon.ico" alt="G" className="w-5 h-5" />
                    Sign in with Google
                  </button>
                </div>
              ) : (
                <div className="space-y-6 animate-fade-in">
                   {step === 'PHONE' ? (
                     <>
                       {/* Name Input added here */}
                       <div>
                         <label className="block text-xs font-bold text-gray-500 mb-2">YOUR NAME</label>
                         <div className="relative">
                           <input 
                             type="text" 
                             value={loginName}
                             onChange={(e) => setLoginName(e.target.value)}
                             className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none font-bold text-lg"
                             placeholder="Enter Name"
                           />
                         </div>
                       </div>

                       <div>
                         <label className="block text-xs font-bold text-gray-500 mb-2">MOBILE NUMBER</label>
                         <div className="relative">
                           <span className="absolute left-4 top-3.5 text-gray-400 font-bold">+91</span>
                           <input 
                             type="tel" 
                             value={phone}
                             onChange={(e) => setPhone(e.target.value)}
                             className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none font-bold text-lg"
                             placeholder="98765 43210"
                           />
                         </div>
                       </div>
                       <button 
                          onClick={handleSendLoginOtp}
                          disabled={loading}
                          className="w-full bg-brand-600 text-white py-4 rounded-xl font-bold hover:bg-brand-700 shadow-lg flex items-center justify-center gap-2"
                       >
                          {loading ? 'Sending OTP...' : <>Get OTP <ArrowRight size={18} /></>}
                       </button>
                     </>
                   ) : (
                     <>
                       <div className="text-center">
                         <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2 text-green-600">
                            <ShieldCheck size={24} />
                         </div>
                         <p className="text-sm text-gray-500">OTP sent to <span className="font-bold text-gray-800">+91 {phone}</span></p>
                       </div>
                       
                       <input 
                         type="text" 
                         value={otp}
                         onChange={(e) => setOtp(e.target.value)}
                         className="w-full text-center py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none font-mono text-2xl tracking-widest"
                         placeholder="000000"
                         maxLength={6}
                       />

                       <button 
                          onClick={handleVerifyLoginOtp}
                          disabled={loading}
                          className="w-full bg-green-600 text-white py-4 rounded-xl font-bold hover:bg-green-700 shadow-lg"
                       >
                          {loading ? 'Verifying...' : 'Verify & Login'}
                       </button>
                       
                       <button 
                         onClick={() => { setStep('PHONE'); setOtp(''); setError(''); window.recaptchaVerifier?.clear(); }}
                         className="w-full text-center text-sm text-gray-400 hover:text-gray-600"
                       >
                         Change Number
                       </button>
                     </>
                   )}
                </div>
              )}
            </div>
          </>
        )}

        {/* --- VIEW: REGISTER --- */}
        {viewMode === 'REGISTER' && (
          <div className="p-8 space-y-5 animate-fade-in">
            {regStep === 'DETAILS' ? (
               <>
                 {/* Image Upload Feature */}
                 <div className="flex justify-center mb-2">
                   <div className="relative group">
                     <div className="w-24 h-24 rounded-full border-4 border-green-100 bg-gray-100 overflow-hidden shadow-inner flex items-center justify-center">
                       {regImage ? (
                         <img src={regImage} alt="Profile" className="w-full h-full object-cover" />
                       ) : (
                         <User size={40} className="text-gray-300" />
                       )}
                     </div>
                     <label className="absolute bottom-0 right-0 bg-green-600 text-white p-2 rounded-full cursor-pointer hover:bg-green-700 shadow-md transition-all active:scale-95">
                       <Camera size={16} />
                       <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                     </label>
                     {regImage && (
                       <button 
                         onClick={() => setRegImage(null)}
                         className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full shadow-md hover:bg-red-600"
                       >
                         <X size={12} />
                       </button>
                     )}
                   </div>
                   <div className="absolute mt-28 text-xs text-gray-400 font-medium">Add Photo</div>
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-gray-500 mb-1 flex items-center gap-1"><User size={14} /> FULL NAME</label>
                   <input 
                     type="text" 
                     value={regName}
                     onChange={(e) => setRegName(e.target.value)}
                     className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
                     placeholder="e.g. John Doe"
                   />
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-gray-500 mb-1 flex items-center gap-1"><Smartphone size={14} /> PHONE NUMBER</label>
                   <div className="relative">
                     <span className="absolute left-4 top-3.5 text-gray-400 font-bold">+91</span>
                     <input 
                       type="tel" 
                       value={regPhone}
                       onChange={(e) => setRegPhone(e.target.value)}
                       className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none font-bold"
                       placeholder="98765 43210"
                     />
                   </div>
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-gray-500 mb-1 flex items-center gap-1"><Briefcase size={14} /> POSITION / ROLE</label>
                   <input 
                     type="text" 
                     value={regPosition}
                     onChange={(e) => setRegPosition(e.target.value)}
                     className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
                     placeholder="e.g. Branch Manager"
                   />
                 </div>

                 <div 
                    onClick={() => setRegBranchConfirmed(!regBranchConfirmed)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-colors flex items-start gap-3 ${regBranchConfirmed ? 'border-green-500 bg-green-50' : 'border-gray-100 bg-gray-50'}`}
                 >
                    <div className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center ${regBranchConfirmed ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-gray-300'}`}>
                       {regBranchConfirmed && <CheckSquare size={14} />}
                    </div>
                    <div>
                       <p className="text-sm font-bold text-gray-800 flex items-center gap-1"><Building2 size={14} className="text-green-600"/> Confirm Branch</p>
                       <p className="text-xs text-gray-500 mt-1">I confirm I am working at <br/><span className="font-semibold text-gray-700">SMES Main Branch, Olagadam</span>.</p>
                    </div>
                 </div>

                 <button 
                    onClick={handleSendRegisterOtp}
                    disabled={loading}
                    className="w-full bg-green-600 text-white py-4 rounded-xl font-bold hover:bg-green-700 shadow-lg flex items-center justify-center gap-2 mt-2"
                 >
                    {loading ? 'Sending OTP...' : <>Get OTP <ArrowRight size={18} /></>}
                 </button>
               </>
            ) : (
               <>
                 <div className="text-center mb-4">
                   <p className="text-sm text-gray-500">Registration OTP sent to <br/><span className="font-bold text-gray-800 text-lg">+91 {regPhone}</span></p>
                 </div>
                 
                 <input 
                   type="text" 
                   value={regOtp}
                   onChange={(e) => setRegOtp(e.target.value)}
                   className="w-full text-center py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none font-mono text-2xl tracking-widest"
                   placeholder="000000"
                   maxLength={6}
                 />

                 <button 
                    onClick={handleCompleteRegistration}
                    disabled={loading}
                    className="w-full bg-green-600 text-white py-4 rounded-xl font-bold hover:bg-green-700 shadow-lg mt-2"
                 >
                    {loading ? 'Verifying...' : 'Verify & Register'}
                 </button>
                 
                 <button 
                   onClick={() => { setRegStep('DETAILS'); setRegOtp(''); setError(''); window.recaptchaVerifier?.clear(); }}
                   className="w-full text-center text-sm text-gray-400 hover:text-gray-600 mt-2"
                 >
                   Edit Details
                 </button>
               </>
            )}
          </div>
        )}

        {/* Global Error Display */}
        {error && (
          <div className="mx-8 mb-6 p-3 bg-red-50 text-red-500 text-sm rounded-lg text-center animate-shake border border-red-100">
            {error}
          </div>
        )}

        {/* Switcher Footer */}
        <div className="bg-gray-50 p-4 border-t border-gray-100 text-center">
           {viewMode === 'LOGIN' ? (
             <p className="text-sm text-gray-600">
               New employee? <button onClick={() => { setViewMode('REGISTER'); setError(''); }} className="text-brand-600 font-bold hover:underline">Register Here</button>
             </p>
           ) : (
             <p className="text-sm text-gray-600">
               Already have an account? <button onClick={() => { setViewMode('LOGIN'); setError(''); }} className="text-brand-600 font-bold hover:underline">Login Here</button>
             </p>
           )}
        </div>
      </div>
      
      <div className="text-white/50 text-xs mt-4">
         SMES Olagadam Main Branch • Official App
      </div>
    </div>
  );
};