import { GoogleGenAI } from "@google/genai";
import { Customer, Language, AppSettings } from '../types';

// Manually declare process to prevent TypeScript errors in Vite environment
declare const process: any;

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generatePaymentReminder = async (customer: Customer, language: Language, settings?: AppSettings): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key not configured. Please check your environment settings.";
  }

  const langPrompt = language === 'ta' 
    ? "in Tamil language (using Tamil script)" 
    : "in English";

  const paymentContext = settings?.upiId 
    ? `The message MUST include the payment instruction: "Pay via GPay/UPI: ${settings.upiId}".`
    : "";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a polite but firm SMS payment reminder ${langPrompt} for a customer named ${customer.name}. 
      They owe ${settings?.currencySymbol || ''}${customer.balance} for a "${customer.itemTaken}". 
      The tone should be professional as it is from the SMES main branch CEO. 
      ${paymentContext}
      Keep it under 160 characters if possible. Do not include placeholders like [Your Name].`,
    });
    return response.text ? response.text.trim() : "Could not generate reminder.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Could not generate reminder at this time.";
  }
};

export const analyzeCustomerRisk = async (customer: Customer, historyText: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key not configured.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following customer data for payment risk:
      Name: ${customer.name}
      Balance: ${customer.balance}
      Total Amount: ${customer.totalAmount}
      Item: ${customer.itemTaken}
      Notes/History: ${historyText || "No additional history provided."}
      
      Provide a brief assessment (Safe, Moderate, High Risk) and a suggested action step for the CEO.`,
    });
    return response.text ? response.text.trim() : "Could not analyze risk.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Could not analyze risk.";
  }
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const translateCustomersToTamil = async (customers: Customer[], onProgress?: (progress: number) => void): Promise<Customer[]> => {
  if (!process.env.API_KEY) {
    console.warn("Skipping translation: No API Key found");
    return JSON.parse(JSON.stringify(customers));
  }

  // Deep copy customers
  const translatedCustomers = JSON.parse(JSON.stringify(customers));
  
  // STABILITY FIX:
  // Reduced Batch Size to 5 to lower token usage and improve stability.
  const BATCH_SIZE = 5;
  const total = customers.length;
  
  // Rate Limit Safety:
  // Free Tier Limit is often 15 Requests Per Minute (RPM).
  // 60 seconds / 15 requests = 4 seconds per request.
  // We use 5000ms (5s) to be absolutely safe (12 requests/min) against strict rate limiters.
  const RPM_DELAY = 5000;

  for (let i = 0; i < total; i += BATCH_SIZE) {
    const chunk = translatedCustomers.slice(i, i + BATCH_SIZE);
    
    // Minify JSON keys to save tokens
    const minifiedChunk = chunk.map((c: any) => ({
      id: c.id,
      n: c.name,       // n = name
      i: c.itemTaken,  // i = item
      a: c.address,    // a = address
      nt: c.notes || '' // nt = notes
    }));

    let retries = 0;
    const maxRetries = 3; // Standard retries for network/parsing errors
    
    let rateLimitRetries = 0;
    const maxRateLimitRetries = 5; // Allow 5 long-wait retries (approx 5 mins of patience) for 429s

    let success = false;

    // Loop continues if success is false AND we haven't exhausted either retry limit
    while (!success && retries <= maxRetries && rateLimitRetries <= maxRateLimitRetries) {
      try {
        // RATE LIMIT THROTTLING
        // Always wait before request to enforce ~12 RPM max speed.
        // We skip delay only for the absolute first batch to start immediately.
        if (i > 0 || retries > 0 || rateLimitRetries > 0) {
           // Calculate backoff for standard retries
           const retryBackoff = retries > 0 ? (Math.pow(2, retries) * 1000) : 0;
           const wait = RPM_DELAY + retryBackoff;
           
           if (retries > 0 || rateLimitRetries > 0) {
             console.log(`Rate Control: Retrying... Waiting ${wait/1000}s...`);
           } else {
             // Standard pacing log (verbose only in debug)
             // console.log(`Rate Control: Pacing...`); 
           }
           
           await delay(wait);
        }

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          config: {
            responseMimeType: "application/json",
            temperature: 0.1, 
          },
          contents: `Translate to Tamil (Tamil Script).
          Input is an array of objects: {id, n (name), i (item), a (address), nt (notes)}.
          
          RULES:
          1. Return JSON Array ONLY.
          2. Transliterate 'n' (Name) phonetically (e.g. "Kumar" -> "குமார்").
          3. Translate 'i', 'a', 'nt' to Tamil meaning.
          4. Keep 'id' EXACTLY as is.
          5. Maintain exact order.
          
          Input: ${JSON.stringify(minifiedChunk)}`
        });

        let translatedChunkText = response.text;
        
        if (translatedChunkText) {
          translatedChunkText = translatedChunkText.replace(/```json/g, '').replace(/```/g, '').trim();
          const translatedChunk = JSON.parse(translatedChunkText);
          
          if (Array.isArray(translatedChunk)) {
            translatedChunk.forEach((tItem: any) => {
              const originalIndex = i + chunk.findIndex((c: any) => c.id === tItem.id);
              if (originalIndex !== -1 && translatedCustomers[originalIndex]) {
                translatedCustomers[originalIndex].name = tItem.n || tItem.name;
                translatedCustomers[originalIndex].itemTaken = tItem.i || tItem.itemTaken;
                translatedCustomers[originalIndex].address = tItem.a || tItem.address;
                translatedCustomers[originalIndex].notes = tItem.nt || tItem.notes;
              }
            });
          }
        }
        success = true;

      } catch (error: any) {
        console.error(`Batch error (Index ${i}, Retry ${retries}, RL Retry ${rateLimitRetries}):`, error);
        
        const errorMsg = error?.message || '';
        const status = error?.status;

        // Detect 429 Resource Exhausted
        const isRateLimit = status === 429 || errorMsg.includes('429') || errorMsg.includes('quota') || errorMsg.includes('RESOURCE_EXHAUSTED');
        
        // Detect 500/503 (Server errors)
        const isServerErr = status === 500 || status === 503;

        if (isRateLimit) {
           console.warn(`Quota Exceeded (429). Pausing for 60 seconds to reset bucket (Attempt ${rateLimitRetries + 1}/${maxRateLimitRetries})...`);
           await delay(60000); // Strict 60s wait for Free Tier bucket reset
           rateLimitRetries++;
           continue; // Retry loop without incrementing standard 'retries' to avoid giving up on quota
        } else if (isServerErr) {
           console.warn("Server Error. Cooling down for 10 seconds...");
           await delay(10000);
           retries++;
        } else {
           // Other errors (Parsing, Network)
           retries++;
        }

        if (retries > maxRetries) {
             console.error("Max standard retries reached for this batch. Moving to next batch with original English data.");
             break; // Stop retrying this batch, keep original data
        }
      }
    }

    if (onProgress) {
      onProgress(Math.min(((i + BATCH_SIZE) / total) * 100, 100));
    }
  }

  return translatedCustomers;
};