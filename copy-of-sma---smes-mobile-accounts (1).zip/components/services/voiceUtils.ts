import { Language } from '../types';

// Browser compatibility types
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

// Wake Lock Sentinel
let wakeLock: any = null;

export const requestWakeLock = async () => {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await (navigator as any).wakeLock.request('screen');
      console.log('Screen Wake Lock active');
    }
  } catch (err) {
    console.warn('Wake Lock request failed:', err);
  }
};

export const releaseWakeLock = async () => {
  if (wakeLock !== null) {
    try {
      await wakeLock.release();
      wakeLock = null;
      console.log('Screen Wake Lock released');
    } catch (err) {
      console.warn('Wake Lock release failed:', err);
    }
  }
};

// 1. Text Parsing Logic (Extract numbers from Tamil/English text)
export const extractNumberFromText = (text: string): number | null => {
  // Remove commas, currency symbols, spaces to clean up
  const cleanText = text.replace(/,/g, '').replace(/[₹$€£]/g, '');
  
  // Match digits (including decimals)
  const matches = cleanText.match(/(\d+(\.\d+)?)/g);
  
  if (matches && matches.length > 0) {
    // Return the last number spoken (usually the most relevant in "Balance is 5000")
    return parseFloat(matches[matches.length - 1]);
  }
  return null;
};

// 2. Audio Recorder (MediaRecorder API)
let mediaRecorder: MediaRecorder | null = null;
let audioChunks: Blob[] = [];

export const startAudioRecording = async (): Promise<void> => {
  try {
    // Try to get audio stream. Note: On mobile during a call, this might be blocked by the OS.
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    audioChunks = [];

    mediaRecorder.ondataavailable = (event) => {
      audioChunks.push(event.data);
    };

    mediaRecorder.start();
  } catch (err) {
    console.error("Error accessing microphone:", err);
    throw new Error("Microphone access denied or in use by another app.");
  }
};

export const stopAudioRecording = (): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!mediaRecorder) {
      resolve('');
      return;
    }

    mediaRecorder.onstop = () => {
      const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = () => {
        const base64String = reader.result as string;
        resolve(base64String); // Return Base64 Data URI
      };
      
      // Stop all tracks to release mic
      mediaRecorder?.stream.getTracks().forEach(track => track.stop());
      mediaRecorder = null;
    };

    if (mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
  });
};

// 3. Speech Recognition (Web Speech API)
export const listenForBalance = (language: Language, onResult: (text: string) => void, onEnd: () => void) => {
  const { webkitSpeechRecognition, SpeechRecognition } = window as unknown as IWindow;
  const SpeechApi = SpeechRecognition || webkitSpeechRecognition;

  if (!SpeechApi) {
    alert("Voice recognition not supported in this browser. Please use Chrome/Edge/Safari.");
    onEnd();
    return null;
  }

  const recognition = new SpeechApi();
  // Map App Language to Speech API Language Code
  recognition.lang = language === 'ta' ? 'ta-IN' : 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = (event: any) => {
    const transcript = event.results[0][0].transcript;
    onResult(transcript);
  };

  recognition.onerror = (event: any) => {
    console.error("Speech recognition error", event.error);
    onEnd();
  };

  recognition.onend = () => {
    onEnd();
  };

  recognition.start();
  return recognition;
};