import { SyncItem, User, AppSettings } from '../types';

const QUEUE_KEY = 'SMA_SYNC_QUEUE';

// Get current queue
export const getSyncQueue = (): SyncItem[] => {
  try {
    const data = localStorage.getItem(QUEUE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

// Add item to queue
export const addToSyncQueue = (actionType: string, description: string, user: User) => {
  const queue = getSyncQueue();
  const newItem: SyncItem = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    actionType,
    description,
    userName: user.name
  };
  
  const updatedQueue = [newItem, ...queue];
  localStorage.setItem(QUEUE_KEY, JSON.stringify(updatedQueue));
  return updatedQueue.length;
};

// Clear queue
export const clearSyncQueue = () => {
  localStorage.removeItem(QUEUE_KEY);
};

// Generate a "Smart Report" file content (JSON or Text)
export const generateSyncReport = (items: SyncItem[]): Blob => {
  const reportData = {
    generatedAt: new Date().toISOString(),
    totalActions: items.length,
    actions: items
  };
  return new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
};

// Generate a human-readable summary for WhatsApp/Text sharing
export const generateReadableSummary = (items: SyncItem[]): string => {
  if (items.length === 0) return "No updates to sync.";

  let summary = `*SMA Team Update* 🚀\n`;
  summary += `📅 ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n`;
  summary += `👤 User: ${items[0].userName}\n`;
  summary += `-------------------\n`;

  // Group by action type
  const calls = items.filter(i => i.actionType.includes('Call'));
  const payments = items.filter(i => i.actionType.includes('Payment') || i.description.includes('Balance'));
  const others = items.filter(i => !calls.includes(i) && !payments.includes(i));

  if (calls.length > 0) summary += `📞 *Calls:* ${calls.length}\n`;
  if (payments.length > 0) summary += `💰 *Financial Updates:* ${payments.length}\n`;
  if (others.length > 0) summary += `📝 *Other Tasks:* ${others.length}\n`;

  summary += `-------------------\n`;
  summary += `*Latest Actions:*\n`;
  
  items.slice(0, 5).forEach(item => {
    const time = new Date(item.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    summary += `• ${time} - ${item.actionType}: ${item.description}\n`;
  });

  if (items.length > 5) summary += `...and ${items.length - 5} more.\n`;

  return summary;
};

// The "Smart Sync" Action
export const performSmartSync = async (settings: AppSettings): Promise<boolean> => {
  const queue = getSyncQueue();
  if (queue.length === 0) return false;

  const summary = generateReadableSummary(queue);
  const blob = generateSyncReport(queue);
  const fileName = `SMA_Update_${new Date().toISOString().slice(0,19).replace(/[:]/g, '-')}.json`;
  const file = new File([blob], fileName, { type: 'application/json' });

  // 1. Try Native Share (Mobile) - Best for Drive/WhatsApp
  // Desktop browsers often return false for `canShare({files...})` or don't support files.
  let shareSuccess = false;
  try {
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        files: [file],
        title: 'SMA Team Update',
        text: summary,
      });
      shareSuccess = true;
    }
  } catch (e) {
    console.warn("Share failed or cancelled", e);
    // Continue to fallback
  }

  if (shareSuccess) return true;

  // 2. Fallback: If Drive Link exists, open it AND download file so user can upload it
  if (settings.driveFolderLink) {
    // Download the file
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Open Drive
    setTimeout(() => {
        window.open(settings.driveFolderLink, '_blank');
    }, 500); // Small delay to ensure download starts
    
    return true;
  }

  // 3. Fallback: Just Download if no drive link
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  return true;
};