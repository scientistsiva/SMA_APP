import { Customer, SheetMetadata, BackupData, User } from '../types';
import { getCurrentUser } from './authService';

// Helper to get keys specific to the logged-in user
const getKeys = () => {
  const user = getCurrentUser();
  const userId = user ? user.id : 'guest';
  return {
    METADATA: `SMA_${userId}_SHEETS_META`,
    DATA_PREFIX: `SMA_${userId}_SHEET_DATA_`
  };
};

// --- Metadata Management ---

export const getSheetList = (): SheetMetadata[] => {
  try {
    const { METADATA } = getKeys();
    const data = localStorage.getItem(METADATA);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Failed to load sheet metadata", e);
    return [];
  }
};

const saveSheetList = (list: SheetMetadata[]) => {
  const { METADATA } = getKeys();
  localStorage.setItem(METADATA, JSON.stringify(list));
};

// --- Sheet Data Management ---

export const saveSheetData = (sheetId: string, customers: Customer[]) => {
  try {
    const { DATA_PREFIX } = getKeys();
    // 1. Save the actual data
    localStorage.setItem(`${DATA_PREFIX}${sheetId}`, JSON.stringify(customers));
    
    // 2. Update metadata (count, balance, and updatedAt)
    const list = getSheetList();
    const sheetIndex = list.findIndex(s => s.id === sheetId);
    
    // Calculate total balance
    const sheetBalance = customers.reduce((sum, c) => sum + (c.balance || 0), 0);
    
    if (sheetIndex >= 0) {
      list[sheetIndex].customerCount = customers.length;
      list[sheetIndex].totalBalance = sheetBalance; // Update balance
      list[sheetIndex].updatedAt = new Date().toISOString();
      saveSheetList(list);
    }
  } catch (e) {
    console.error("Failed to save sheet data", e);
    alert("Storage limit reached. Please delete old sheets or images.");
  }
};

export const createNewSheet = (name: string, customers: Customer[]): string => {
  const newId = crypto.randomUUID();
  const now = new Date().toISOString();
  
  // Calculate total balance
  const sheetBalance = customers.reduce((sum, c) => sum + (c.balance || 0), 0);

  const newSheet: SheetMetadata = {
    id: newId,
    name: name,
    createdAt: now,
    updatedAt: now,
    customerCount: customers.length,
    totalBalance: sheetBalance // Save balance
  };

  // Save Data first
  try {
    const { DATA_PREFIX } = getKeys();
    localStorage.setItem(`${DATA_PREFIX}${newId}`, JSON.stringify(customers));
    
    // Then Metadata
    const list = getSheetList();
    saveSheetList([newSheet, ...list]); // Add to top
    return newId;
  } catch (e) {
    alert("Not enough space to create new sheet.");
    throw e;
  }
};

export const loadSheetData = (sheetId: string): Customer[] => {
  try {
    const { DATA_PREFIX } = getKeys();
    const data = localStorage.getItem(`${DATA_PREFIX}${sheetId}`);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error(`Failed to load data for sheet ${sheetId}`, e);
    return [];
  }
};

export const deleteSheet = (sheetId: string) => {
  const { DATA_PREFIX } = getKeys();
  // Remove data
  localStorage.removeItem(`${DATA_PREFIX}${sheetId}`);
  
  // Remove from list
  const list = getSheetList().filter(s => s.id !== sheetId);
  saveSheetList(list);
};

export const renameSheet = (sheetId: string, newName: string) => {
  const list = getSheetList();
  const sheet = list.find(s => s.id === sheetId);
  if (sheet) {
    sheet.name = newName;
    sheet.updatedAt = new Date().toISOString();
    saveSheetList(list);
  }
};

// --- New Logic: Calculate Total Balance & Count of ALL English Sheets ---
export const calculateGlobalStats = (): { balance: number, count: number } => {
  const list = getSheetList();
  let totalBalance = 0;
  let totalCount = 0;
  
  // Filter for sheets that DO NOT contain 'tamil' in the name (case insensitive)
  // We assume Tamil sheets are translations and shouldn't be counted in the grand total
  const englishSheets = list.filter(s => !s.name.toLowerCase().includes('tamil'));

  englishSheets.forEach(sheet => {
    totalCount += (sheet.customerCount || 0);

    // Optimization: If metadata has totalBalance, use it.
    if (typeof sheet.totalBalance === 'number') {
      totalBalance += sheet.totalBalance;
    } else {
      // Fallback: If old sheet without metadata, load data to calculate (slower but accurate)
      try {
        const data = loadSheetData(sheet.id);
        const sheetTotal = data.reduce((sum, c) => sum + (c.balance || 0), 0);
        totalBalance += sheetTotal;
      } catch (e) {
        console.warn(`Could not calculate balance for sheet ${sheet.name}`);
      }
    }
  });

  return { balance: totalBalance, count: totalCount };
};

// --- Backup & Cloud Sync Utilities ---

export const generateBackup = (): Blob => {
  const metadata = getSheetList();
  const sheets: Record<string, Customer[]> = {};
  
  metadata.forEach(m => {
    sheets[m.id] = loadSheetData(m.id);
  });

  const backup: BackupData = {
    metadata,
    sheets,
    version: 1,
    timestamp: new Date().toISOString()
  };

  return new Blob([JSON.stringify(backup)], { type: 'application/json' });
};

export const restoreFromBackup = async (file: File): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = e.target?.result as string;
        const backup: BackupData = JSON.parse(json);

        if (!backup.metadata || !backup.sheets) {
          throw new Error("Invalid backup format");
        }

        const { DATA_PREFIX } = getKeys();

        // Restore Metadata
        saveSheetList(backup.metadata);

        // Restore Sheets
        Object.entries(backup.sheets).forEach(([id, data]) => {
          localStorage.setItem(`${DATA_PREFIX}${id}`, JSON.stringify(data));
        });

        resolve(true);
      } catch (err) {
        console.error("Restore failed", err);
        reject(err);
      }
    };
    reader.readAsText(file);
  });
};

// --- Export Utilities ---

// 1. Basic Customer Export
export const exportToCSV = (customers: Customer[], fileName: string) => {
  const headers = ['Name', 'Phone', 'Item Taken', 'Total Amount', 'Balance', 'Date', 'Address', 'Notes'];
  const csvContent = [
    headers.join(','),
    ...customers.map(c => [
      `"${c.name}"`,
      `"${c.phone}"`,
      `"${c.itemTaken}"`,
      c.totalAmount,
      c.balance,
      `"${c.date}"`,
      `"${c.address}"`,
      `"${c.notes || ''}"`
    ].join(','))
  ].join('\n');

  triggerDownload(csvContent, `${fileName}.csv`, 'text/csv;charset=utf-8;');
};

// 2. Detailed Call Report Export (Requested Feature)
export const exportCallReport = (customers: Customer[], sheetName: string) => {
  const headers = ['Date', 'Time', 'Customer Name', 'Phone', 'Caller (User)', 'Outcome', 'Duration/Notes', 'Payment Promise', 'Audio Note'];
  
  const rows: string[][] = [];

  customers.forEach(c => {
    // A. Process Modern Activity Logs
    if (c.activityLogs) {
      c.activityLogs.forEach(log => {
        if (log.type === 'CALL') {
           const d = new Date(log.timestamp);
           rows.push([
             d.toLocaleDateString('en-GB'),
             d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
             `"${c.name}"`,
             `"${c.phone}"`,
             `"${log.userName}"`,
             log.callOutcome || 'Unknown',
             `"${log.details.replace(/"/g, '""')}"`,
             c.promisedPaymentDate ? new Date(c.promisedPaymentDate).toLocaleDateString('en-GB') : '-',
             log.audioUrl ? "Yes" : "No"
           ]);
        }
      });
    }

    // B. Process Legacy Call History
    if (c.callHistory) {
      c.callHistory.forEach(call => {
         // Check if already processed in logs to avoid duplicates
         const exists = c.activityLogs?.some(al => al.timestamp === call.date && al.type === 'CALL');
         if (!exists) {
            const d = new Date(call.date);
            rows.push([
               d.toLocaleDateString('en-GB'),
               d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
               `"${c.name}"`,
               `"${c.phone}"`,
               `"System"`,
               'CONNECTED', // Assume legacy is connected
               `"${(call.notes || '').replace(/"/g, '""')}"`,
               '-',
               'No'
            ]);
         }
      });
    }
  });

  // Sort by date descending (Newest first)
  rows.sort((a,b) => {
     // rudimentary date sort, relying on ISO timestamp would be better but this works for display
     return 0; // Keeping input order for now or can implement robust date parsing
  });

  const csvContent = [
    headers.join(','),
    ...rows.map(r => r.join(','))
  ].join('\n');

  triggerDownload(csvContent, `SMA_Call_Report_${sheetName}_${new Date().toISOString().slice(0,10)}.csv`, 'text/csv;charset=utf-8;');
};

// Helper to trigger download
const triggerDownload = (content: string, fileName: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};