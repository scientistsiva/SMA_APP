import { User } from '../types';

const USER_KEY = 'SMA_CURRENT_USER';
const OTP_STORAGE = 'SMA_TEMP_OTP';
const USERS_DB_KEY = 'SMA_USERS_DB'; // Persist users between sessions

// --- Helper for Mock DB ---
const getUsersDb = (): Record<string, User> => {
  try {
    const json = localStorage.getItem(USERS_DB_KEY);
    return json ? JSON.parse(json) : {};
  } catch {
    return {};
  }
};

const saveUserToDb = (user: User) => {
  const db = getUsersDb();
  // Normalize phone key
  const key = user.emailOrPhone.replace(/\D/g, '');
  if (key) {
    db[key] = user;
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(db));
  }
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(USER_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const logoutUser = () => {
  localStorage.removeItem(USER_KEY);
  // We do NOT clear data, just the session
};

// --- Simulated Google Login ---
export const loginWithGoogle = async (): Promise<User> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate random user for demo purposes, or a fixed one
      const mockUser: User = {
        id: 'google_user_ceo',
        name: 'SMES CEO',
        emailOrPhone: 'ceo@smes-olagadam.com',
        avatar: 'https://ui-avatars.com/api/?name=SMES+CEO&background=0ea5e9&color=fff',
        type: 'GOOGLE',
        position: 'CEO'
      };
      localStorage.setItem(USER_KEY, JSON.stringify(mockUser));
      saveUserToDb(mockUser);
      resolve(mockUser);
    }, 1500); // Fake network delay
  });
};

// --- Simulated Mobile OTP Flow ---

export const sendOtp = async (phoneNumber: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Generate a random 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      
      // In a real app, this calls an API (Twilio/Firebase)
      console.log(`OTP sent to ${phoneNumber}: ${otp}`);
      
      // Store for verification
      localStorage.setItem(OTP_STORAGE, otp);
      
      resolve(otp);
    }, 1000);
  });
};

export const verifyOtp = async (phoneNumber: string, otp: string, name?: string): Promise<User | null> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const storedOtp = localStorage.getItem(OTP_STORAGE);
      
      // Verify against stored OTP (allow 123456 as master bypass for demo)
      if (otp === storedOtp || otp === '123456') {
        const cleanPhone = phoneNumber.replace(/\D/g, '');
        
        // 1. Check if user exists in our mock DB
        const db = getUsersDb();
        let user = db[cleanPhone];

        // 2. Determine Name
        // If name provided during login, use it. Otherwise fallback to DB name or generated name.
        const displayName = name && name.trim().length > 0 
           ? name 
           : (user ? user.name : `Staff ${cleanPhone.slice(-4)}`);

        // 3. Create or Update User
        if (!user) {
           // New User
           user = {
            id: 'mobile_user_' + cleanPhone,
            name: displayName,
            emailOrPhone: phoneNumber,
            type: 'MOBILE',
            position: 'Staff'
          };
        } else {
           // Existing User - Update name if provided explicitly during login
           if (name && name.trim().length > 0) {
               user.name = name;
           }
        }

        // Save and Persist
        saveUserToDb(user);
        localStorage.setItem(USER_KEY, JSON.stringify(user));
        localStorage.removeItem(OTP_STORAGE);
        resolve(user);
      } else {
        reject(new Error("Invalid OTP"));
      }
    }, 1000);
  });
};

export const registerUser = async (phoneNumber: string, otp: string, name: string, position: string, avatar?: string): Promise<User | null> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const storedOtp = localStorage.getItem(OTP_STORAGE);
      
      // Verify against stored OTP
      if (otp === storedOtp || otp === '123456') {
        const newUser: User = {
          id: 'mobile_user_' + phoneNumber.replace(/\D/g, ''),
          name: name,
          emailOrPhone: phoneNumber,
          type: 'MOBILE',
          position: position,
          // Use provided avatar or generate one based on name
          avatar: avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=10b981&color=fff`
        };
        
        saveUserToDb(newUser); // Persist details for future logins
        localStorage.setItem(USER_KEY, JSON.stringify(newUser));
        localStorage.removeItem(OTP_STORAGE);
        resolve(newUser);
      } else {
        reject(new Error("Invalid OTP"));
      }
    }, 1000);
  });
};