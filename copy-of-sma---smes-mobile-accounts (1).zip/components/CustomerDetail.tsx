import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  ArrowLeft, Phone, MapPin, Save, Camera, MessageSquare, 
  Trash2, CreditCard, Calendar, User, Sparkles, X, History,
  Edit3, CheckCircle, Mic, PhoneOff, PhoneMissed, PhoneIncoming,
  CalendarClock, MicOff, Share2, QrCode, Copy, DownloadCloud, Activity,
  Wallet, ChevronRight, Plus, RefreshCw, Send, Volume2, Zap, Minimize2, Navigation
} from 'lucide-react';
import { Customer, ActivityLog, Language, AppSettings, User as AppUser, ActivityType, CallOutcome } from '../types';
import { generatePaymentReminder } from '../services/geminiService';
import { startAudioRecording, stopAudioRecording, listenForBalance, extractNumberFromText, requestWakeLock, releaseWakeLock } from '../services/voiceUtils';
import { addToSyncQueue } from '../services/syncService';
import { TranslationKeys } from '../constants/translations';

interface CustomerDetailProps {
  customer: Customer;
  onBack: () => void;
  onUpdate: (updatedCustomer: Customer) => void;
  onDelete: (id: string) => void;
  language: Language;
  settings: AppSettings;
  user: AppUser;
  t: TranslationKeys;
}

// Date Format Helper: DD-MM-YYYY
const formatDate = (dateStr: string | undefined | null) => {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr || '';
    return d.toLocaleDateString('en-GB').replace(/\//g, '-');
  } catch (e) {
    return dateStr || '';
  }
};

const extractAmountFromDetails = (details: string): string => {
  const match = details.match(/(\d+(\.\d+)?)/);
  return match ? match[0] : '-';
};

// Smart Phone Formatter for WhatsApp (India Default +91)
const getSmartWhatsappNumber = (rawPhone: string) => {
  let clean = rawPhone.replace(/\D/g, '');
  
  // Smart AI Logic for Indian Numbers
  // 1. If length is 10, assume local mobile -> add 91
  if (clean.length === 10) {
     return '91' + clean; 
  } 
  // 2. If length > 10 and starts with 0 (e.g. 098...), strip 0 and add 91
  else if (clean.length > 10 && clean.startsWith('0')) {
     return '91' + clean.substring(1); 
  } 
  // 3. If length is 12 and starts with 91, keep it
  else if (clean.length === 12 && clean.startsWith('91')) {
     return clean; 
  }
  
  // Fallback for other formats
  return clean;
};

export const CustomerDetail: React.FC<CustomerDetailProps> = ({ 
  customer, onBack, onUpdate, onDelete, language, settings, user, t 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Customer>(customer);
  const [aiMessage, setAiMessage] = useState<string>('');
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [showHistory, setShowHistory] = useState(true); 
  const [showPhoneMenu, setShowPhoneMenu] = useState(false);
  
  // Replaced Modal with Bottom Sheet logic
  const [showPostCallSheet, setShowPostCallSheet] = useState(false);
  const [callFlowStep, setCallFlowStep] = useState<'ANALYZING' | 'OUTCOME' | 'PROMISE'>('OUTCOME');
  
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [autoDetected, setAutoDetected] = useState<'SUCCESS' | 'FAIL' | null>(null);
  const [callDurationSec, setCallDurationSec] = useState(0);
  
  // Manual Payment State
  const [paymentEntryAmount, setPaymentEntryAmount] = useState<string>('');
  const [showManualEntry, setShowManualEntry] = useState(false);

  // --- Call Session State ---
  const [isCallSessionActive, setIsCallSessionActive] = useState(false);
  const [activeCallNumber, setActiveCallNumber] = useState<string | null>(null);
  const callStartTimeRef = useRef<number | null>(null);
  
  // Voice State
  const [isRecording, setIsRecording] = useState(false);
  const [tempAudio, setTempAudio] = useState<string | null>(null);
  const [recognitionText, setRecognitionText] = useState('');

  // Sync if prop changes
  useEffect(() => {
    setFormData(customer);
  }, [customer]);

  // Sync payment amount when modal opens
  useEffect(() => {
    if (showPaymentModal) {
      setPaymentAmount(formData.balance);
    }
  }, [showPaymentModal, formData.balance]);

  // Handle Wake Lock for Call Session
  useEffect(() => {
    if (isCallSessionActive) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }
    return () => { releaseWakeLock(); };
  }, [isCallSessionActive]);

  // --- Smart Call Recognition Logic ---
  useEffect(() => {
    const handleVisibilityChange = () => {
      // If user returns to app AND we were in a call session
      if (document.visibilityState === 'visible' && isCallSessionActive && callStartTimeRef.current) {
         const durationMs = Date.now() - callStartTimeRef.current;
         const durationSec = Math.round(durationMs / 1000);
         setCallDurationSec(durationSec);
         console.log(`Call Session Duration: ${durationMs}ms`);
         
         // STOP RECORDING AUTOMATICALLY ON RETURN
         if (isRecording) {
            stopAudioRecording().then(audio => {
               setTempAudio(audio);
               setIsRecording(false);
            }).catch(e => console.error("Auto-stop recording failed", e));
         }

         // HIDE OVERLAY IMMEDIATELY so user sees customer page
         setIsCallSessionActive(false);
         setShowPostCallSheet(true);
         setCallFlowStep('ANALYZING');

         // Smart AI Logic for Post-Call Sheet
         setTimeout(() => {
            // Threshold: 10 seconds. 
            // > 10s: Connected (Success) -> Go straight to Promise
            // < 10s: Failed/No Answer -> Go to Outcome selector
            if (durationMs > 10000) {
                setAutoDetected('SUCCESS');
                setCallFlowStep('PROMISE'); // Skip outcome, assume connected
            } else {
                setAutoDetected('FAIL');
                setCallFlowStep('OUTCOME');
            }
         }, 800); 

         callStartTimeRef.current = null; // Reset
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isCallSessionActive, isRecording]);

  // Parse phone numbers
  const phoneNumbers = useMemo(() => {
    if (!formData.phone) return [];
    return formData.phone.split(/[,\/&|]+/).map(p => p.trim()).filter(Boolean);
  }, [formData.phone]);

  const recentPayments = useMemo(() => {
    return (formData.activityLogs || [])
      .filter(log => log.type === 'PAYMENT')
      .slice(0, 10); // Show last 10
  }, [formData.activityLogs]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const addActivityLog = (type: ActivityType, details: string, outcome?: CallOutcome, audioUrl?: string) => {
    const newLog: ActivityLog = {
      id: crypto.randomUUID(),
      type,
      userId: user.id,
      userName: user.name,
      timestamp: new Date().toISOString(),
      details,
      callOutcome: outcome,
      audioUrl: audioUrl
    };
    
    // Add to Sync Queue
    addToSyncQueue(
      type === 'CALL' ? `Call: ${outcome || 'Attempt'}` : type, 
      `${details} (Customer: ${formData.name})`, 
      user
    );

    // Return updated logs array
    return [newLog, ...(formData.activityLogs || [])];
  };

  const handleManualPayment = () => {
     const amount = parseFloat(paymentEntryAmount);
     if (!amount || amount <= 0) {
        alert("Please enter a valid amount");
        return;
     }

     if (!confirm(`Confirm receiving ${settings.currencySymbol}${amount} from ${formData.name}?`)) {
        return;
     }

     const newBalance = Math.max(0, formData.balance - amount);
     
     // Log the payment
     const details = `Payment Received: ${settings.currencySymbol}${amount} (New Bal: ${newBalance})`;
     const updatedLogs = addActivityLog('PAYMENT', details);
     
     const updatedCustomer = { 
        ...formData, 
        balance: newBalance,
        activityLogs: updatedLogs
     };

     setFormData(updatedCustomer);
     onUpdate(updatedCustomer);
     setPaymentEntryAmount('');
  };

  const handleSave = () => {
    // 1. Detect Changes (Audit)
    const changes: string[] = [];
    let logType: ActivityType = 'UPDATE';
    let logDetails = '';

    // Prioritize Voice Update
    if (tempAudio) {
       logType = 'VOICE_UPDATE';
       logDetails = `Voice Update: "${recognitionText}" (Balance set to ${formData.balance})`;
    } else {
      // Standard Changes
      if (formData.balance !== customer.balance) {
        changes.push(`Balance changed from ${customer.balance} to ${formData.balance}`);
      }
      if (formData.totalAmount !== customer.totalAmount) {
        changes.push(`Total changed from ${customer.totalAmount} to ${formData.totalAmount}`);
      }
      if (formData.phone !== customer.phone) changes.push(`Phone updated`);
      if (formData.address !== customer.address) changes.push(`Address updated`);
      if (formData.name !== customer.name) changes.push(`Name changed to ${formData.name}`);
      if (formData.itemTaken !== customer.itemTaken) changes.push(`Item updated: ${formData.itemTaken}`);
      if (formData.notes !== customer.notes) changes.push(`Notes updated`);

      logDetails = changes.length > 0 ? changes.join(', ') : 'Updated customer details';
    }

    let updatedCustomer = { ...formData };
    
    // Attach log (including audio if present)
    updatedCustomer.activityLogs = addActivityLog(
        logType, 
        logDetails, 
        undefined, 
        tempAudio || undefined
    );

    onUpdate(updatedCustomer);
    setIsEditing(false);
    
    // Cleanup Temp State
    setTempAudio(null);
    setRecognitionText('');
  };

  // --- Voice Handlers ---
  const handleVoiceStart = async () => {
    setIsRecording(true);
    setRecognitionText('Listening...');
    setTempAudio(null); // Clear previous

    try {
      // 1. Start Audio Recording (File)
      await startAudioRecording();

      // 2. Start Speech Recognition (Text)
      listenForBalance(
        language,
        (text) => {
           console.log("Speech Result:", text);
           setRecognitionText(text);
           const num = extractNumberFromText(text);
           if (num !== null) {
              setFormData(prev => ({ ...prev, balance: num }));
           }
        },
        async () => {
           // On End of Speech
           const audioBase64 = await stopAudioRecording();
           setTempAudio(audioBase64);
           setIsRecording(false);
        }
      );
    } catch (e) {
      console.error(e);
      setIsRecording(false);
      alert("Could not start voice recording. Check permissions.");
    }
  };

  // Specific handler for Call Notes Recording (only audio, no balance parsing logic)
  const handleCallRecordingStart = async () => {
    try {
      setRecognitionText('Recording call note...');
      await startAudioRecording();
      setIsRecording(true);
    } catch (e) {
      console.warn("Auto-record trigger fail", e);
      setIsRecording(false);
    }
  };

  const handleStopRecordingManual = async () => {
     // Force stop if user clicks button manually
     if (isRecording) {
        const audioBase64 = await stopAudioRecording();
        setTempAudio(audioBase64);
        setIsRecording(false);
     }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        alert("File is too large. Please select an image under 10MB.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_SIZE = 500;
          if (width > height) {
             if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; }
          } else {
             if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
            
            // Immediately update with log
            const updatedLogs = addActivityLog('UPDATE', 'Updated profile photo');
            const updatedCustomer = { ...formData, imageUrl: dataUrl, activityLogs: updatedLogs };
            setFormData(updatedCustomer);
            onUpdate(updatedCustomer);
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
     const updatedLogs = addActivityLog('UPDATE', 'Removed profile photo');
     const updatedCustomer = { ...formData, imageUrl: undefined, activityLogs: updatedLogs };
     setFormData(updatedCustomer);
     onUpdate(updatedCustomer);
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData(prev => ({
            ...prev,
            location: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            }
          }));
        },
        (error) => alert('Error fetching location: ' + error.message)
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  // Main Call Handler
  const handleCallClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (phoneNumbers.length > 1) {
      setShowPhoneMenu(true);
    } else if (phoneNumbers.length === 1) {
      initiateCall(phoneNumbers[0]);
    } else {
      alert("No valid phone number found.");
    }
  };

  const initiateCall = async (number: string) => {
    // 1. Set Active Call Session (Shows Overlay)
    setActiveCallNumber(number);
    setIsCallSessionActive(true);
    setShowPhoneMenu(false);

    // 2. Start Timer for Smart Detection
    callStartTimeRef.current = Date.now();
    setAutoDetected(null); // Reset

    // 3. SMART AI: Auto Start Recording
    try {
      await startAudioRecording();
      setIsRecording(true);
      setRecognitionText("Auto-recording active (Speaker mode recommended)...");
    } catch (e) {
      console.warn("Auto-record failed on init", e);
    }

    // 4. Trigger native call after a slight delay to allow UI to render
    setTimeout(() => {
        window.location.href = `tel:${number}`;
    }, 1200); // 1.2s delay to read the "Speaker" prompt
  };

  const endCallSession = () => {
    setIsCallSessionActive(false);
    callStartTimeRef.current = null;
    
    if (isRecording) {
      stopAudioRecording().then(audio => {
         setTempAudio(audio);
         setIsRecording(false);
      });
    }

    // Manual End -> Default to OUTCOME Selection (Bottom Sheet)
    setCallFlowStep('OUTCOME');
    setShowPostCallSheet(true);
  };

  const saveCallOutcome = (outcome: CallOutcome) => {
     if (outcome === 'CONNECTED') {
         // Transition to Step 2: Payment Promise
         setCallFlowStep('PROMISE');
         setAutoDetected('SUCCESS');
     } else {
         // Save immediately for failed calls
         let details = '';
         if (outcome === 'DECLINED') details = 'Call Declined / Cut';
         if (outcome === 'NO_ANSWER') details = 'No Answer';

         const noteSuffix = tempAudio ? ' (Voice Note Attached)' : '';
         const updatedLogs = addActivityLog('CALL', details + noteSuffix, outcome, tempAudio || undefined);
         const updatedCustomer = { ...formData, activityLogs: updatedLogs };
         setFormData(updatedCustomer);
         onUpdate(updatedCustomer);
         
         setShowPostCallSheet(false);
         setTempAudio(null);
         setAutoDetected(null);
     }
  };

  const savePromise = (days: number | null) => {
      let details = '';
      let isoDate = undefined;

      if (days !== null) {
          const date = new Date();
          date.setDate(date.getDate() + days);
          isoDate = date.toISOString();
          const readableDate = date.toLocaleDateString('en-GB').replace(/\//g, '-');
          details = `Connected: Promised to pay in ${days} ${t.days} (${readableDate})`;
      } else {
          details = 'Connected: No specific promise date';
      }

      const noteSuffix = tempAudio ? ' (Voice Note Attached)' : '';
      const updatedLogs = addActivityLog('CALL', details + noteSuffix, 'CONNECTED', tempAudio || undefined);
      
      const updatedCustomer = { 
          ...formData, 
          activityLogs: updatedLogs,
          promisedPaymentDate: isoDate 
      };
      
      setFormData(updatedCustomer);
      onUpdate(updatedCustomer);
      
      setShowPostCallSheet(false);
      setCallFlowStep('OUTCOME');
      setTempAudio(null);
      setAutoDetected(null);
  };

  const handleGenerateMessage = async () => {
    setIsLoadingAi(true);
    // PASS SETTINGS so AI includes UPI context
    const msg = await generatePaymentReminder(formData, language, settings);
    setAiMessage(msg);
    setIsLoadingAi(false);
    
    // Log AI usage
    const updatedLogs = addActivityLog('AI', 'Generated AI Payment Reminder');
    const updatedCustomer = { ...formData, activityLogs: updatedLogs };
    setFormData(updatedCustomer);
    onUpdate(updatedCustomer);
  };
  
  const handleWhatsapp = () => {
     if (phoneNumbers.length === 0) {
         alert("No phone number available");
         return;
     }
     
     // Use smart formatted number
     const cleanPhone = getSmartWhatsappNumber(phoneNumbers[0]);
     
     let text = aiMessage || `Hello ${formData.name}, this is a reminder regarding your balance of ${settings.currencySymbol}${formData.balance}.`;
     
     if (settings.upiId) {
       const amount = formData.balance * settings.conversionRate;
       const upiLink = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.merchantName || 'SMES')}&am=${amount}&cu=${settings.currencyCode || 'INR'}`;
       text += `\n\n💰 *Pay Now (GPay/UPI)*: ${upiLink}`;
     }

     const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
     window.open(url, '_blank');
  };

  const mapLink = formData.location 
    ? `https://www.google.com/maps/search/?api=1&query=${formData.location.lat},${formData.location.lng}` 
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(formData.address)}`;

  const formatMoney = (val: number) => {
    return (val * settings.conversionRate).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  };

  const upiLink = useMemo(() => {
    if (!settings.upiId) return '';
    const amount = (paymentAmount * settings.conversionRate).toFixed(2);
    return `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.merchantName || 'SMES')}&am=${amount}&cu=${settings.currencyCode || 'INR'}`;
  }, [paymentAmount, settings]);

  const qrCodeUrl = useMemo(() => {
     if(!upiLink) return '';
     return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiLink)}`;
  }, [upiLink]);

  const handleSharePaymentDetails = (method: 'WHATSAPP' | 'SMS' | 'SHARE') => {
      const text = `*Payment Request from ${settings.merchantName || 'SMES'}*\n` +
      `----------------------------\n` +
      `Customer: ${formData.name}\n` +
      `Item: ${formData.itemTaken}\n` +
      `Date: ${formatDate(new Date().toISOString())}\n` +
      `----------------------------\n` +
      `Total Balance: ${settings.currencySymbol}${formatMoney(formData.balance)}\n` +
      `*Paying Amount: ${settings.currencySymbol}${formatMoney(paymentAmount)}*\n` +
      `----------------------------\n` +
      `Pay to UPI ID: ${settings.upiId}\n\n` +
      `Tap to Pay: ${upiLink}`;

      if (method === 'SHARE' && navigator.share) {
         navigator.share({
           title: 'Payment Request',
           text: text,
           url: upiLink
         }).catch(console.error);
      } else if (method === 'WHATSAPP') {
         if (phoneNumbers.length > 0) {
            const cleanPhone = getSmartWhatsappNumber(phoneNumbers[0]);
            window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`, '_blank');
         } else {
             window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
         }
      } else if (method === 'SMS') {
          const smsBody = `Pay ${settings.currencySymbol}${formatMoney(paymentAmount)} to UPI: ${settings.upiId} for ${formData.itemTaken}.`;
          const cleanPhone = phoneNumbers.length > 0 ? phoneNumbers[0].replace(/\D/g, '') : '';
          window.location.href = `sms:${cleanPhone}?body=${encodeURIComponent(smsBody)}`;
      }
  };

  const combinedHistory = useMemo(() => {
    const logs = [...(formData.activityLogs || [])];
    if (formData.callHistory && formData.callHistory.length > 0) {
       formData.callHistory.forEach(legacy => {
          const exists = logs.some(l => l.timestamp === legacy.date && l.type === 'CALL');
          if (!exists) {
            logs.push({
               id: legacy.id,
               type: 'CALL',
               userId: 'legacy',
               userName: 'Previous System',
               timestamp: legacy.date,
               details: legacy.notes || 'Outgoing Call',
               callOutcome: 'CONNECTED' 
            });
          }
       });
    }
    return logs.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [formData.activityLogs, formData.callHistory]);

  const handleDownloadAudio = (base64Data: string, fileName: string) => {
     const link = document.createElement('a');
     link.href = base64Data;
     link.download = fileName + '.webm';
     document.body.appendChild(link);
     link.click();
     document.body.removeChild(link);
  };

  return (
    <div className="bg-white min-h-screen pb-20 relative">
      
      {/* 
        ========================================
        SMART CALL SESSION COMPANION MODE
        ========================================
      */}
      {isCallSessionActive && (
        <div className="fixed inset-0 z-[100] bg-gray-950 flex flex-col animate-fade-in">
           {/* Top Stats */}
           <div className="pt-10 px-6 pb-6 bg-gradient-to-b from-gray-900 to-gray-950 relative">
              
              {/* Minimize Button */}
              <button 
                onClick={() => setIsCallSessionActive(false)}
                className="absolute top-4 right-4 p-2 bg-white/10 rounded-full text-white/70 hover:bg-white/20 hover:text-white transition-colors"
                title="Minimize Overlay"
              >
                 <Minimize2 size={24} />
              </button>

              <div className="flex justify-between items-start mb-6">
                 <div>
                    <div className="flex items-center gap-2 mb-1">
                       <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_10px_red]"></span>
                       <span className="text-red-400 font-bold text-xs uppercase tracking-widest">Live Call Active</span>
                    </div>
                    <div className="text-gray-400 text-xs font-mono mb-2">Since {new Date().toLocaleTimeString()}</div>
                    <h2 className="text-3xl font-bold text-white leading-tight">{formData.name}</h2>
                    <p className="text-xl text-gray-300 font-mono mt-1 tracking-wide">{activeCallNumber}</p>
                 </div>
                 <div className="w-16 h-16 rounded-full bg-gray-800 overflow-hidden border-2 border-gray-700 shadow-xl">
                    {formData.imageUrl ? (
                      <img src={formData.imageUrl} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-500"><User size={32}/></div>
                    )}
                 </div>
              </div>
              
              {/* Smart Reminder Box */}
              <div className="bg-blue-900/20 border border-blue-500/30 p-4 rounded-xl flex items-center gap-4 animate-pulse">
                 <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-400">
                    <Volume2 size={24} />
                 </div>
                 <div>
                    <h3 className="text-blue-100 font-bold text-sm">Turn on Speakerphone</h3>
                    <p className="text-blue-300 text-xs">AI is listening to record this call automatically.</p>
                 </div>
              </div>
           </div>

           {/* Main Data Card */}
           <div className="flex-1 bg-white rounded-t-[2.5rem] p-8 relative shadow-2xl overflow-y-auto">
              <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-12 h-1.5 bg-gray-200 rounded-full"></div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center">
                     <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Balance Due</span>
                     <span className="text-2xl font-black text-red-600">{settings.currencySymbol}{formatMoney(formData.balance)}</span>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center">
                     <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Last Item</span>
                     <span className="text-sm font-bold text-gray-800 line-clamp-2">{formData.itemTaken}</span>
                  </div>
              </div>

              <div className="mb-6">
                 <h3 className="text-gray-400 text-xs font-bold uppercase mb-2">Customer Notes</h3>
                 <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 text-gray-700 text-sm italic relative">
                    <div className="absolute -top-2 -left-2 bg-yellow-400 text-white p-1 rounded-full shadow-sm"><Zap size={12} fill="white"/></div>
                    {formData.notes || "No notes available for this customer."}
                 </div>
              </div>

              {/* Live Recording Status */}
              <div className="mb-8">
                 <h3 className="text-gray-400 text-xs font-bold uppercase mb-3 flex items-center gap-2">
                    <Activity size={14} /> AI Recording Status
                 </h3>
                 
                 {isRecording ? (
                    <div className="bg-red-50 border border-red-100 p-6 rounded-2xl flex flex-col items-center justify-center gap-3">
                       <div className="flex items-center gap-3">
                          <span className="relative flex h-4 w-4">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
                          </span>
                          <span className="text-red-600 font-bold text-lg">Recording Active...</span>
                       </div>
                       <p className="text-xs text-red-400 text-center">Keep app open. Use Speakerphone.</p>
                       <button 
                         onClick={handleStopRecordingManual}
                         className="mt-2 bg-white border border-red-200 text-red-600 px-6 py-2 rounded-full font-bold text-sm shadow-sm hover:bg-red-50"
                       >
                         Stop Recording
                       </button>
                    </div>
                 ) : (
                    <div className="bg-gray-100 border border-gray-200 p-4 rounded-2xl text-center">
                        <p className="text-gray-500 text-sm mb-2">Recording Paused / Stopped</p>
                        <button 
                           onClick={handleCallRecordingStart}
                           className="bg-gray-800 text-white px-6 py-2 rounded-full text-sm font-bold"
                        >
                           Resume Recording
                        </button>
                    </div>
                 )}
              </div>
           </div>

           {/* End Call Action */}
           <div className="bg-white p-4 border-t border-gray-100 pb-8">
              <button 
                onClick={endCallSession}
                className="w-full bg-gray-900 text-white py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-black transition-colors flex items-center justify-center gap-2"
              >
                 <PhoneOff size={24} className="text-red-400" /> End Session & Save
              </button>
           </div>
        </div>
      )}

      {/* Manual Payment Entry Modal */}
      {showManualEntry && (
         <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in">
             <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl animate-slide-up">
                 <div className="flex justify-between items-center mb-6">
                     <h3 className="text-xl font-bold text-gray-800">Record Payment</h3>
                     <button onClick={() => setShowManualEntry(false)} className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-gray-200">
                         <X size={20} />
                     </button>
                 </div>
                 
                 {/* Amount Input */}
                 <div className="mb-6">
                    <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Amount Received</label>
                    <div className="relative">
                       <span className="absolute left-4 top-4 text-2xl font-bold text-gray-400">{settings.currencySymbol}</span>
                       <input 
                          type="number" 
                          value={paymentEntryAmount}
                          onChange={(e) => setPaymentEntryAmount(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 text-3xl font-bold text-gray-800 border-b-2 border-gray-200 focus:border-emerald-500 outline-none bg-transparent"
                          placeholder="0"
                          autoFocus
                       />
                    </div>
                 </div>

                 {/* Quick Presets */}
                 <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-2">
                    {[100, 200, 500, 1000, 2000].map(amt => (
                       <button 
                          key={amt}
                          onClick={() => setPaymentEntryAmount(amt.toString())}
                          className="px-4 py-2 bg-emerald-50 text-emerald-700 font-bold rounded-full border border-emerald-100 hover:bg-emerald-100 whitespace-nowrap shadow-sm"
                       >
                          +{amt}
                       </button>
                    ))}
                    <button 
                       onClick={() => setPaymentEntryAmount(formData.balance.toString())}
                       className="px-4 py-2 bg-blue-50 text-blue-700 font-bold rounded-full border border-blue-100 hover:bg-blue-100 whitespace-nowrap shadow-sm"
                    >
                       Full Due
                    </button>
                 </div>

                 {/* Action */}
                 <button 
                     onClick={() => {
                         handleManualPayment(); 
                         setShowManualEntry(false);
                     }}
                     className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg shadow-lg hover:bg-emerald-700 flex items-center justify-center gap-2"
                 >
                     <CheckCircle size={20} /> Confirm Payment
                 </button>
             </div>
         </div>
      )}

      {/* Payment / G-Pay Modal */}
      {showPaymentModal && (
         <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in overflow-y-auto">
             <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-scale-in relative my-auto">
                <button 
                  onClick={() => setShowPaymentModal(false)}
                  className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full text-gray-500 hover:bg-gray-200 z-10"
                >
                   <X size={20} />
                </button>
                {/* ... existing content ... */}
                <div className="text-center mb-6 mt-2">
                   <h3 className="font-bold text-2xl text-gray-800 flex items-center justify-center gap-2">
                      <QrCode className="text-blue-600" /> {t.scanToPay}
                   </h3>
                   <p className="text-gray-500 text-sm mt-1">{settings.merchantName || 'SMES Merchant'}</p>
                </div>

                {settings.upiId ? (
                   <div className="space-y-6">
                      <div className="bg-gray-50 rounded-xl p-4 text-sm space-y-2 border border-gray-100 shadow-inner">
                          <div className="flex justify-between items-center">
                              <span className="text-gray-500">Customer</span>
                              <span className="font-bold text-gray-900 truncate max-w-[150px]">{formData.name}</span>
                          </div>
                          <div className="flex justify-between items-center">
                              <span className="text-gray-500">Total Balance</span>
                              <span className="font-bold text-gray-700">{settings.currencySymbol}{formatMoney(formData.balance)}</span>
                          </div>
                      </div>
                      
                      <div>
                         <label className="block text-xs font-bold text-blue-600 uppercase mb-1 ml-1 tracking-wider">Amount to Collect</label>
                         <div className="relative">
                            <span className="absolute left-4 top-3.5 text-gray-400 font-bold text-lg">{settings.currencySymbol}</span>
                            <input 
                              type="number" 
                              value={paymentAmount}
                              onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-blue-100 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-50 outline-none font-bold text-2xl text-gray-800 transition-all shadow-sm"
                            />
                         </div>
                      </div>

                      <div className="flex flex-col items-center">
                         <div className="bg-white p-3 rounded-2xl border-2 border-dashed border-gray-300 shadow-sm relative group">
                            <img src={qrCodeUrl} alt="UPI QR" className="w-48 h-48 object-contain mix-blend-multiply" />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 backdrop-blur-sm rounded-xl">
                               <span className="font-bold text-gray-600 text-sm">Scan with GPay/PhonePe</span>
                            </div>
                         </div>
                         <p className="text-xs text-gray-400 mt-2 font-mono">{settings.upiId}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                         <button onClick={() => handleSharePaymentDetails('WHATSAPP')} className="bg-[#25D366] text-white py-3 rounded-xl font-bold hover:bg-[#128C7E] flex items-center justify-center gap-2 shadow-lg shadow-green-100 transition-transform active:scale-95"><Share2 size={18} /> WhatsApp</button>
                         <a href={upiLink} className="bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 flex items-center justify-center gap-2 shadow-lg shadow-blue-100 transition-transform active:scale-95"><CreditCard size={18} /> Open App</a>
                      </div>
                   </div>
                ) : (
                   <div className="bg-red-50 text-red-600 p-6 rounded-2xl text-center border border-red-100"><p className="font-bold">{t.upiNotConfigured}</p></div>
                )}
             </div>
         </div>
      )}

      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b shadow-sm px-4 py-3 flex items-center justify-between">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-lg font-bold text-gray-800 truncate max-w-[200px]">
          {isEditing ? t.editCustomer : t.customerProfile}
        </h1>
        <button 
          onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${
            isEditing 
              ? 'bg-brand-600 text-white hover:bg-brand-700' 
              : 'text-brand-600 hover:bg-brand-50'
          }`}
        >
          {isEditing ? <span className="flex items-center gap-1"><Save size={16} /> {t.save}</span> : t.edit}
        </button>
      </div>

      <div className="p-4 space-y-6">
        {/* Profile Image */}
        <div className="flex flex-col items-center relative">
          <div className="relative w-32 h-32 mb-4 group">
            {formData.imageUrl ? (
              <img src={formData.imageUrl} alt={formData.name} className="w-full h-full object-cover rounded-full border-4 border-gray-100 shadow-lg" />
            ) : (
              <div className="w-full h-full rounded-full bg-brand-100 flex items-center justify-center text-brand-500 border-4 border-white shadow-lg">
                <User size={48} />
              </div>
            )}
            
            {isEditing && (
              <>
                <label className="absolute bottom-0 right-0 bg-brand-600 text-white p-2 rounded-full shadow-lg cursor-pointer hover:bg-brand-700 transition-colors z-10">
                  <Camera size={20} />
                  <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                </label>
                
                {formData.imageUrl && (
                  <button 
                    onClick={handleRemoveImage}
                    className="absolute bottom-0 left-0 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600 transition-colors z-10"
                    title="Remove Photo"
                  >
                    <X size={20} />
                  </button>
                )}
              </>
            )}
          </div>
          
          {/* Smart Map Navigator (Floating Right of Profile) */}
          {!isEditing && (
             <a 
               href={mapLink}
               target="_blank" 
               rel="noopener noreferrer"
               className="absolute right-2 top-20 p-3 bg-white border border-gray-100 text-blue-600 rounded-full shadow-lg hover:bg-blue-50 z-10 transition-transform active:scale-95"
               title={t.map}
             >
                <Navigation size={22} fill="currentColor" className="text-blue-500" />
             </a>
          )}
          
          {isEditing ? (
            <div className="w-full space-y-2">
              <input 
                type="text" 
                name="name" 
                value={formData.name} 
                onChange={handleChange}
                className="text-2xl font-bold text-center border-b-2 border-brand-200 focus:border-brand-600 focus:outline-none w-full"
                placeholder={t.customerName}
              />
              <div className="flex items-center justify-center gap-2">
                <span className="text-gray-400 text-sm">S.No:</span>
                <input 
                  type="text" 
                  name="sNo" 
                  value={formData.sNo || ''} 
                  onChange={handleChange}
                  className="text-sm border-b border-gray-300 w-20 text-center focus:outline-none"
                  placeholder="#"
                />
              </div>
            </div>
          ) : (
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900">{formData.name}</h2>
              {formData.sNo && (
                <span className="inline-block mt-1 px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full">
                  #{formData.sNo}
                </span>
              )}
            </div>
          )}
          <div className="text-gray-500 text-sm mt-1 flex flex-col items-center">
             {phoneNumbers.length > 0 ? (
               phoneNumbers.map((num, i) => <span key={i}>{num}{i < phoneNumbers.length - 1 ? ',' : ''}</span>)
             ) : (
               <span>{formData.phone}</span>
             )}
             {isEditing && (
               <input 
                 name="phone" 
                 value={formData.phone} 
                 onChange={handleChange} 
                 className="mt-2 border-b border-gray-300 text-center focus:outline-none text-gray-800" 
                 placeholder="Phone numbers (comma separated)"
               />
             )}
          </div>
        </div>

        {/* Quick Actions (Call/Pay) */}
        {!isEditing && (
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={handleCallClick}
              className="flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl font-bold shadow-lg hover:bg-green-600 transition-transform active:scale-95 cursor-pointer"
            >
              <Phone size={20} /> {t.callNow}
            </button>
            <button 
              onClick={() => setShowPaymentModal(true)}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl font-bold shadow-lg hover:bg-blue-700 transition-transform active:scale-95"
            >
              <QrCode size={20} /> Pay / QR
            </button>
          </div>
        )}

        {/* Financial Details Card */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
          <h3 className="text-sm uppercase tracking-wide text-slate-500 font-bold mb-4 flex items-center gap-2">
            <CreditCard size={16} /> {t.emiDetails}
          </h3>
          
          {/* Promised Date Badge */}
          {formData.promisedPaymentDate && (
             <div className="absolute top-0 right-0 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-bl-2xl text-xs font-bold flex items-center gap-1 shadow-sm">
                <CalendarClock size={14} /> 
                {t.promisedOn}: {formatDate(formData.promisedPaymentDate)}
             </div>
          )}

          <div className="space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <span className="text-gray-600">{t.itemTaken}</span>
              {isEditing ? (
                <input name="itemTaken" value={formData.itemTaken} onChange={handleChange} className="text-right bg-white border rounded p-1" />
              ) : (
                <span className="font-semibold text-gray-900">{formData.itemTaken}</span>
              )}
            </div>
            
            {/* Balance Edit with Voice Feature */}
            <div className="flex justify-between items-center pb-2 relative">
              <span className="text-gray-600 font-bold shrink-0">{t.balanceDue}</span>
              
              {isEditing ? (
                <div className="flex items-center gap-2">
                   <div className="relative">
                     <input 
                       name="balance" 
                       type="number" 
                       value={formData.balance} 
                       onChange={handleChange} 
                       className="text-right bg-white border rounded p-1 text-red-600 font-bold w-28" 
                     />
                   </div>
                   
                   {/* Voice Button */}
                   <button 
                     onClick={isRecording ? handleStopRecordingManual : handleVoiceStart}
                     className={`p-2 rounded-full transition-all ${
                       isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-brand-100 text-brand-600 hover:bg-brand-200'
                     }`}
                     title="Tap to Speak Balance"
                   >
                     {isRecording ? <MicOff size={16} /> : <Mic size={16} />}
                   </button>
                </div>
              ) : (
                 <span className="font-bold text-red-600 text-xl shrink-0">{settings.currencySymbol}{formatMoney(formData.balance)}</span>
              )}
            </div>
            
            {/* Voice Recognition Feedback */}
            {isEditing && (isRecording || recognitionText) && (
               <div className="bg-gray-100 p-2 rounded text-xs text-gray-600 mt-2 text-right">
                  {isRecording ? "Listening..." : `Recognized: "${recognitionText}"`}
               </div>
            )}
             {isEditing && tempAudio && (
               <div className="text-right text-xs text-green-600 font-bold flex items-center justify-end gap-1 mt-1">
                 <CheckCircle size={12}/> Audio Recorded (Will save on 'Save')
               </div>
            )}

            {/* Address Field (Moved here from below) */}
            <div className="pt-2 border-t border-slate-200">
               <div className="flex items-start gap-2">
                 <MapPin className="text-gray-400 mt-1 shrink-0" size={16} />
                 <div className="flex-1">
                   <label className="text-xs font-bold text-gray-500 block mb-1">{t.address}</label>
                   {isEditing ? (
                      <textarea name="address" value={formData.address} onChange={handleChange} className="w-full border p-2 rounded focus:outline-none bg-white" rows={2} />
                   ) : (
                     <p className="text-gray-800 text-sm leading-snug">{formData.address}</p>
                   )}
                   {isEditing && (
                     <button 
                       onClick={handleGetLocation} 
                       className="mt-2 text-xs bg-brand-100 text-brand-700 px-3 py-1 rounded-full flex items-center gap-1"
                     >
                       <MapPin size={12} /> {t.setLocation}
                     </button>
                   )}
                 </div>
               </div>
            </div>

            {/* Date Field (Requested below address) */}
            <div className="pt-2 border-t border-slate-200">
               <div className="flex items-start gap-2">
                 <Calendar className="text-gray-400 mt-0.5 shrink-0" size={16} />
                 <div className="flex-1">
                   <label className="text-xs font-bold text-gray-500 block mb-1">{t.date}</label>
                   {isEditing ? (
                      <input name="date" value={formData.date} onChange={handleChange} className="w-full border p-1 rounded focus:outline-none bg-white text-sm" placeholder="DD-MM-YYYY" />
                   ) : (
                     <p className="text-gray-800 text-sm font-medium">{formatDate(formData.date)}</p>
                   )}
                 </div>
               </div>
            </div>
          </div>
        </div>

        {/* 
           REORDERED SECTIONS:
           1. Activity & History
           2. Payments Section (Recent & Add New)
           3. AI Assistant
        */}
        {!isEditing ? (
          <div className="space-y-6">
            
            {/* 1. Audit Timeline Section */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <button 
                  onClick={() => setShowHistory(!showHistory)}
                  className="w-full p-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <span className="font-bold text-gray-700 flex items-center gap-2">
                    <History size={18} className="text-brand-600"/> Activity & History
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-white border border-gray-200 px-2 py-1 rounded-full text-gray-500">
                      {combinedHistory.length}
                    </span>
                    <span className={`text-gray-400 transition-transform ${showHistory ? 'rotate-180' : ''}`}>▼</span>
                  </div>
                </button>
                
                {showHistory && (
                  <div className="p-4 bg-gray-50 border-t border-gray-100 max-h-80 overflow-y-auto custom-scrollbar">
                    {combinedHistory.length === 0 ? (
                      <p className="text-sm text-gray-400 text-center italic py-2">{t.noCalls}</p>
                    ) : (
                      <div className="space-y-4 pl-2">
                        {combinedHistory.map((log) => {
                          // Determine Icon and Color based on type AND call outcome
                          let icon = <CheckCircle size={14} />;
                          let colorClass = 'bg-gray-100 text-gray-500';
                          
                          if (log.type === 'CALL') {
                             if (log.callOutcome === 'CONNECTED' || !log.callOutcome) {
                                icon = <PhoneIncoming size={14} />;
                                colorClass = 'bg-green-100 text-green-600';
                             } else if (log.callOutcome === 'DECLINED') {
                                icon = <PhoneOff size={14} />;
                                colorClass = 'bg-red-100 text-red-600';
                             } else if (log.callOutcome === 'NO_ANSWER') {
                                icon = <PhoneMissed size={14} />;
                                colorClass = 'bg-orange-100 text-orange-600';
                             }
                          } else if (log.type === 'PAYMENT') {
                             icon = <Wallet size={14} />;
                             colorClass = 'bg-emerald-100 text-emerald-600';
                          } else if (log.type === 'UPDATE') {
                            icon = <Edit3 size={14} />;
                            colorClass = 'bg-blue-100 text-blue-600';
                          } else if (log.type === 'VOICE_UPDATE') {
                            icon = <Mic size={14} />;
                            colorClass = 'bg-pink-50 text-pink-600';
                          } else if (log.type === 'AI') {
                            icon = <Sparkles size={14} />;
                            colorClass = 'bg-purple-100 text-purple-600';
                          } else if (log.type === 'NOTE') {
                            icon = <MessageSquare size={14} />;
                            colorClass = 'bg-yellow-100 text-yellow-600';
                          }

                          return (
                            <div key={log.id} className="flex gap-3 relative">
                               {/* Timeline Line */}
                               <div className="absolute left-[14px] top-8 bottom-[-16px] w-[2px] bg-gray-200 last:hidden"></div>
                               
                               {/* Icon */}
                               <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 z-10 border-2 border-white shadow-sm ${colorClass}`}>
                                  {icon}
                               </div>

                               {/* Content */}
                               <div className="flex-1 pb-1">
                                  <div className="flex justify-between items-start">
                                     <p className="text-sm font-bold text-gray-800">
                                       {log.userName || 'Unknown User'}
                                     </p>
                                     <span className="text-[10px] text-gray-400 whitespace-nowrap ml-2">
                                       {new Date(log.timestamp).toLocaleDateString('en-GB').replace(/\//g, '-')} {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                     </span>
                                  </div>
                                  <p className="text-xs text-gray-600 mt-0.5 font-medium">{log.details}</p>
                                  
                                  {/* Audio Player if present */}
                                  {log.audioUrl && (
                                    <div className="mt-2 bg-gray-50 border border-gray-100 p-2 rounded-lg flex items-center gap-2">
                                       <div onClick={(e) => { e.stopPropagation(); /* prevent bubbling */ }}>
                                          <audio controls src={log.audioUrl} className="h-6 w-40" />
                                       </div>
                                       <button 
                                          onClick={() => handleDownloadAudio(log.audioUrl!, `voice_note_${log.id}`)}
                                          className="p-1.5 text-blue-500 hover:bg-blue-50 rounded"
                                          title="Download Audio to Cloud/Device"
                                       >
                                          <DownloadCloud size={14} />
                                       </button>
                                    </div>
                                  )}
                                  
                                  {/* Tag */}
                                  <span className={`inline-block text-[10px] px-1.5 py-0.5 rounded mt-1 uppercase tracking-wide font-bold ${
                                    log.callOutcome === 'DECLINED' ? 'bg-red-50 text-red-700' :
                                    log.callOutcome === 'NO_ANSWER' ? 'bg-orange-50 text-orange-700' :
                                    log.type === 'CALL' ? 'bg-green-50 text-green-700' :
                                    log.type === 'PAYMENT' ? 'bg-emerald-50 text-emerald-700' :
                                    log.type === 'UPDATE' ? 'bg-blue-50 text-blue-700' :
                                    log.type === 'VOICE_UPDATE' ? 'bg-pink-50 text-pink-700' :
                                    'bg-gray-100 text-gray-600'
                                  }`}>
                                    {log.callOutcome || log.type}
                                  </span>
                               </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
            </div>

            {/* 2. Payments Section (Recent & Add New) */}
            <div className="space-y-4">
               {/* Recent Payments List (Green Boxes) */}
               <div>
                  <h3 className="text-sm font-bold text-gray-700 mb-2 flex items-center justify-between">
                     <span className="flex items-center gap-2"><Wallet size={16} className="text-emerald-600"/> Recent Payments</span>
                  </h3>
                  {recentPayments.length > 0 ? (
                     <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                        {recentPayments.map(pay => {
                           const amt = extractAmountFromDetails(pay.details);
                           // Format if it's a valid number
                           const displayAmt = amt === '-' ? '-' : parseFloat(amt).toLocaleString('en-IN');
                           return (
                             <div key={pay.id} className="shrink-0 bg-emerald-100 text-emerald-800 p-3 rounded-lg border border-emerald-200 min-w-[120px] shadow-sm">
                                <div className="font-bold text-lg text-emerald-700">
                                   {settings.currencySymbol}{displayAmt}
                                </div>
                                <div className="text-[10px] uppercase font-bold text-emerald-600 mt-1 flex items-center gap-1">
                                   <Calendar size={10} /> {new Date(pay.timestamp).toLocaleDateString()}
                                </div>
                             </div>
                           );
                        })}
                     </div>
                  ) : (
                     <div className="p-4 bg-gray-50 rounded-xl border border-dashed border-gray-300 text-center text-xs text-gray-400">
                        No payments recorded yet.
                     </div>
                  )}
               </div>

               {/* Add Payment Button */}
               <button 
                  onClick={() => setShowManualEntry(true)}
                  className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2"
               >
                  <Plus size={20} /> Add New Payment
               </button>
            </div>

            {/* 3. AI Assistant Section */}
            <div className="bg-gradient-to-r from-violet-50 to-fuchsia-50 p-5 rounded-2xl border border-violet-100 shadow-sm relative overflow-hidden">
                 <h3 className="text-sm font-bold text-violet-800 mb-3 flex items-center gap-2">
                    <Sparkles size={16} /> {t.aiAssistant}
                 </h3>
                 
                 {!aiMessage ? (
                    <button 
                      onClick={handleGenerateMessage}
                      disabled={isLoadingAi}
                      className="w-full bg-white text-violet-700 border border-violet-200 py-3 rounded-xl font-bold shadow-sm hover:bg-violet-50 flex items-center justify-center gap-2 transition-all"
                    >
                       {isLoadingAi ? (
                         <>
                           <div className="animate-spin h-4 w-4 border-2 border-violet-500 border-t-transparent rounded-full"></div>
                           Generating...
                         </>
                       ) : (
                         <>
                           <Sparkles size={18} /> Generate Payment Reminder
                         </>
                       )}
                    </button>
                 ) : (
                    <div className="animate-fade-in">
                       <textarea 
                          value={aiMessage}
                          onChange={(e) => setAiMessage(e.target.value)}
                          className="w-full p-3 text-sm border border-violet-200 rounded-xl bg-white mb-3 focus:ring-2 focus:ring-violet-500 outline-none shadow-inner"
                          rows={4}
                       />
                       <div className="flex gap-2">
                          <button 
                            onClick={handleWhatsapp}
                            className="flex-1 bg-[#25D366] text-white py-3 rounded-xl font-bold shadow-md hover:bg-[#128C7E] flex items-center justify-center gap-2"
                          >
                             <MessageSquare size={18} /> WhatsApp (Pay Link)
                          </button>
                          <button 
                             onClick={() => {
                                const cleanPhone = phoneNumbers[0]?.replace(/\D/g, '');
                                window.location.href = `sms:${cleanPhone}?body=${encodeURIComponent(aiMessage)}`;
                             }}
                             className="px-4 bg-gray-200 text-gray-700 rounded-xl hover:bg-gray-300 flex items-center justify-center"
                          >
                             <Send size={18} />
                          </button>
                          <button 
                            onClick={() => setAiMessage('')}
                            className="px-4 text-violet-400 hover:text-violet-600"
                            title="Clear"
                          >
                            <RefreshCw size={18} />
                          </button>
                       </div>
                       {settings.upiId && (
                          <p className="text-[10px] text-violet-500 mt-2 flex items-center gap-1 font-medium bg-violet-100/50 px-2 py-1 rounded-lg inline-block">
                             <CheckCircle size={10} /> Smart Link included for {settings.upiId}
                          </p>
                       )}
                    </div>
                 )}
            </div>

          </div>
        ) : (
           /* Notes Only Visible In Edit Mode */
           <div className="space-y-4">
             <div className="flex items-start gap-3">
               <MessageSquare className="text-gray-400 mt-1" size={20} />
               <div className="flex-1">
                 <label className="text-xs font-bold text-gray-500">{t.notes}</label>
                 <textarea name="notes" value={formData.notes || ''} onChange={handleChange} className="w-full border p-2 rounded focus:outline-none" rows={3} />
               </div>
             </div>
           </div>
        )}

        {isEditing && (
          <button 
            onClick={() => {
              if (confirm(t.confirmDelete)) {
                onDelete(customer.id);
              }
            }}
            className="w-full mt-8 border border-red-200 text-red-600 py-3 rounded-xl font-bold hover:bg-red-50"
          >
            <span className="flex items-center justify-center gap-2"><Trash2 size={18} /> {t.deleteCustomer}</span>
          </button>
        )}
      </div>
    </div>
  );
};