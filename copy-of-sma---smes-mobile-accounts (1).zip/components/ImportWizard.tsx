import React, { useState, useRef } from 'react';
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle } from 'lucide-react';
import { Customer } from '../types';
import { TranslationKeys } from '../constants/translations';

// Declare XLSX global since we loaded it via CDN
declare const XLSX: any;

interface ImportWizardProps {
  onImport: (customers: Customer[], fileName: string) => void;
  onCancel: () => void;
  t: TranslationKeys;
}

export const ImportWizard: React.FC<ImportWizardProps> = ({ onImport, onCancel, t }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [error, setError] = useState<string>('');
  const [mapping, setMapping] = useState({
    sNo: '',
    name: '',
    phone: '',
    item: '',
    balance: '',
    date: '',
    address: '',
    total: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      parseExcel(selectedFile);
    }
  };

  const parseExcel = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        if (jsonData.length > 0) {
          setPreview(jsonData);
          // Auto-guess mapping based on header row (row 0)
          const headers = jsonData[0] as string[];
          const newMapping = { ...mapping };
          
          headers.forEach((h, index) => {
            const header = h.toString().toLowerCase();
            if ((header.includes('s.no') || header.includes('sl.no') || header === 'no.' || header.includes('serial')) && !header.includes('phone')) newMapping.sNo = index.toString();
            else if (header.includes('name') || header.includes('customer')) newMapping.name = index.toString();
            else if (header.includes('phone') || header.includes('mobile')) newMapping.phone = index.toString();
            else if (header.includes('item') || header.includes('thing') || header.includes('product')) newMapping.item = index.toString();
            else if (header.includes('balance') || header.includes('due')) newMapping.balance = index.toString();
            else if (header.includes('date') || header.includes('time')) newMapping.date = index.toString();
            else if (header.includes('address') || header.includes('loc')) newMapping.address = index.toString();
            else if (header.includes('total') || header.includes('price')) newMapping.total = index.toString();
          });
          setMapping(newMapping);
        }
      } catch (err) {
        setError('Failed to parse Excel file. Please ensure it is a valid .xlsx or .xls file.');
        console.error(err);
      }
    };
    reader.readAsBinaryString(file);
  };

  const processImport = () => {
    if (!preview.length) return;
    
    // Skip header row
    const dataRows = preview.slice(1);
    
    const customers: Customer[] = dataRows.map((row, idx) => {
      // Helper to safely get string
      const getVal = (idxStr: string) => {
        const i = parseInt(idxStr);
        return !isNaN(i) && row[i] !== undefined ? String(row[i]).trim() : '';
      };
      
      // Helper to safely get number
      const getNum = (idxStr: string) => {
        const val = getVal(idxStr).replace(/[^0-9.-]+/g, '');
        return parseFloat(val) || 0;
      };

      const name = getVal(mapping.name);
      const sNo = getVal(mapping.sNo);
      const phone = getVal(mapping.phone);
      const balance = getNum(mapping.balance);

      // --- FILTER LOGIC ---
      
      // 1. Mandatory Check: Name must exist.
      if (!name) return null;

      // 2. Mandatory Check: Phone Number must exist (Requested Update).
      // If the phone string is empty or just whitespace, skip this customer.
      if (!phone || phone.trim() === '') return null;

      return {
        id: crypto.randomUUID(),
        sNo: sNo,
        name: name,
        phone: phone,
        itemTaken: getVal(mapping.item) || 'Unknown Item',
        balance: balance,
        totalAmount: getNum(mapping.total),
        date: getVal(mapping.date) || new Date().toISOString(),
        address: getVal(mapping.address),
        notes: ''
      };
    }).filter(c => c !== null) as Customer[]; 

    // Use filename without extension as sheet name
    const sheetName = file ? file.name.replace(/\.[^/.]+$/, "") : "Imported Sheet";
    onImport(customers, sheetName);
  };

  const headers = preview.length > 0 ? (preview[0] as string[]) : [];

  return (
    <div className="p-4 max-w-lg mx-auto bg-white rounded-xl shadow-md border border-gray-100">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <FileSpreadsheet className="text-green-600" />
        {t.importTitle}
      </h2>
      
      {!file ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 transition-colors"
        >
          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-3" />
          <p className="text-gray-600 font-medium">{t.uploadPrompt}</p>
          <p className="text-sm text-gray-400 mt-1">Supports standard Excel formats</p>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept=".xlsx, .xls, .csv" 
            className="hidden" 
          />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-green-50 p-3 rounded-lg text-green-700">
            <span className="flex items-center gap-2 text-sm font-medium">
              <CheckCircle size={16} />
              {file.name}
            </span>
            <button 
              onClick={() => { setFile(null); setPreview([]); }}
              className="text-xs underline hover:text-green-900"
            >
              {t.change}
            </button>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm flex items-center gap-2">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          {preview.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-gray-700">{t.mapColumns}</h3>
              <p className="text-xs text-gray-500">{t.mapColumnsDesc}</p>
              
              <div className="grid grid-cols-1 gap-3">
                {[
                  { label: t.sNo, key: 'sNo' },
                  { label: t.customerName, key: 'name' },
                  { label: t.phoneNumber, key: 'phone' },
                  { label: t.itemTaken, key: 'item' },
                  { label: t.balanceDue, key: 'balance' },
                  { label: t.date, key: 'date' },
                ].map((field) => (
                  <div key={field.key} className="flex flex-col">
                    <label className="text-xs font-semibold text-gray-600 mb-1">{field.label}</label>
                    <select 
                      className="border border-gray-300 rounded p-2 text-sm"
                      value={mapping[field.key as keyof typeof mapping]}
                      onChange={(e) => setMapping({...mapping, [field.key]: e.target.value})}
                    >
                      <option value="">{t.selectColumn}</option>
                      {headers.map((h, i) => (
                        <option key={i} value={i}>{h || `Column ${i+1}`}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-3 mt-6">
            <button 
              onClick={onCancel}
              className="flex-1 py-3 text-gray-600 font-medium bg-gray-100 rounded-lg hover:bg-gray-200"
            >
              {t.cancel}
            </button>
            <button 
              onClick={processImport}
              className="flex-1 py-3 text-white font-bold bg-brand-600 rounded-lg shadow-lg hover:bg-brand-700 flex justify-center items-center gap-2"
            >
              {t.importData}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};