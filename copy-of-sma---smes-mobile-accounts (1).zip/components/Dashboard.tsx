import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, Plus, Download, Users, DollarSign, IndianRupee, Euro, PoundSterling, JapaneseYen,
  TrendingUp, FileSpreadsheet, Menu, X, FileText, Trash2, Settings,
  Sparkles, Languages, FolderOpen, ChevronDown, ChevronUp, LogOut, User as UserIcon, History,
  CheckCircle, XCircle, PhoneMissed, CalendarClock, BellRing, Globe, PieChart, Cloud, UploadCloud, Phone, RefreshCw, Calendar, Wallet,
  Zap, ArrowRight
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { Customer, Language, SheetMetadata, AppSettings, User } from '../types';
import { exportToCSV, exportCallReport, generateBackup, calculateGlobalStats } from '../services/storageService';
import { getSyncQueue, performSmartSync, clearSyncQueue } from '../services/syncService';
import { TranslationKeys } from '../constants/translations';

interface DashboardProps {
  customers: Customer[];
  sheets: SheetMetadata[];
  activeSheetId: string | null;
  onSelectSheet: (id: string) => void;
  onDeleteSheet: (id: string) => void;
  onSelectCustomer: (customer: Customer) => void;
  onImportClick: () => void;
  onAddNew: () => void;
  onTranslateSheet: () => void;
  onOpenSheetManager: () => void;
  onOpenSettings: () => void;
  onOpenHistory: () => void;
  onOpenAnalytics: () => void;
  onOpenTeamPerformance: () => void; // New prop for Team/Working stats
  onLogout: () => void;
  user: User | null;
  isTranslating: boolean;
  translationProgress: number; // New prop for progress
  language: Language;
  setLanguage: (lang: Language) => void;
  settings: AppSettings;
  t: TranslationKeys;
}

// Helper to render correct icon
const CurrencyIcon = ({ symbol, className }: { symbol: string, className?: string }) => {
  switch (symbol) {
    case '₹': return <IndianRupee className={className} size={16} />;
    case '€': return <Euro className={className} size={16} />;
    case '£': return <PoundSterling className={className} size={16} />;
    case '¥': return <JapaneseYen className={className} size={16} />;
    default: return <DollarSign className={className} size={16} />;
  }
};

// Date Format Helper: DD-MM-YYYY
const formatDate = (dateStr: string | undefined | null) => {
  if (!dateStr) return 'No Date';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr; // Return as is if invalid date
    return d.toLocaleDateString('en-GB').replace(/\//g, '-');
  } catch (e) {
    return dateStr;
  }
};

export const Dashboard: React.FC<DashboardProps> = ({ 
  customers, 
  sheets,
  activeSheetId,
  onSelectSheet,
  onDeleteSheet,
  onSelectCustomer, 
  onImportClick,
  onAddNew,
  onTranslateSheet,
  onOpenSheetManager,
  onOpenSettings,
  onOpenHistory,
  onOpenAnalytics,
  onOpenTeamPerformance,
  onLogout,
  user,
  isTranslating,
  translationProgress,
  language,
  setLanguage,
  settings,
  t
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'ALL' | 'DEBT' | 'CONNECTED' | 'FAILED' | 'FOLLOW_UP'>('ALL');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showTop10, setShowTop10] = useState(false);
  
  // State for Global Stats (Balance + Count)
  const [globalStats, setGlobalStats] = useState({ balance: 0, count: 0 });
  
  // State for Sync Queue
  const [pendingSyncCount, setPendingSyncCount] = useState(0);

  const activeSheet = sheets.find(s => s.id === activeSheetId);

  // Recalculate global balance/count whenever sheets or active customers change
  useEffect(() => {
    const stats = calculateGlobalStats();
    setGlobalStats(stats);
    
    // Check Sync Queue
    const queue = getSyncQueue();
    setPendingSyncCount(queue.length);
  }, [sheets, customers]); // Re-run when data changes (which implies potential sync actions)

  // --- Compute Live Counts ---
  const counts = useMemo(() => {
    const today = new Date().toDateString();
    let connected = 0;
    let failed = 0;
    let followUp = 0;

    customers.forEach(c => {
      // Check calls today
      const todayLogs = c.activityLogs?.filter(l => l.type === 'CALL' && new Date(l.timestamp).toDateString() === today);
      
      if (todayLogs?.some(l => l.callOutcome === 'CONNECTED')) {
        connected++;
      }
      
      if (todayLogs?.some(l => l.callOutcome === 'DECLINED' || l.callOutcome === 'NO_ANSWER')) {
        // Only count as failed if they didn't eventually connect today
        if (!todayLogs?.some(l => l.callOutcome === 'CONNECTED')) {
          failed++;
        }
      }

      // Check smart follow up
      if (c.promisedPaymentDate) {
        const promised = new Date(c.promisedPaymentDate);
        const now = new Date();
        promised.setHours(0,0,0,0);
        now.setHours(0,0,0,0);
        if (promised <= now && c.balance > 0) {
          followUp++;
        }
      }
    });

    return { connected, failed, followUp };
  }, [customers]);

  const filteredCustomers = useMemo(() => {
    const today = new Date().toDateString();

    return customers.filter(c => {
      // 1. Search Logic
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.phone.includes(searchTerm) ||
                          (c.sNo && c.sNo.includes(searchTerm));
      
      // 2. Filter Logic
      let matchesFilter = true;
      
      if (filter === 'DEBT') {
        matchesFilter = c.balance > 0;
      } else if (filter === 'CONNECTED') {
        matchesFilter = c.activityLogs?.some(l => 
          l.type === 'CALL' && 
          l.callOutcome === 'CONNECTED' && 
          new Date(l.timestamp).toDateString() === today
        ) || false;
      } else if (filter === 'FAILED') {
        const hasFailed = c.activityLogs?.some(l => 
          l.type === 'CALL' && 
          (l.callOutcome === 'DECLINED' || l.callOutcome === 'NO_ANSWER') && 
          new Date(l.timestamp).toDateString() === today
        );
        const hasConnected = c.activityLogs?.some(l => 
          l.type === 'CALL' && 
          l.callOutcome === 'CONNECTED' && 
          new Date(l.timestamp).toDateString() === today
        );
        matchesFilter = (hasFailed && !hasConnected) || false;
      } else if (filter === 'FOLLOW_UP') {
        if (c.promisedPaymentDate && c.balance > 0) {
           const promised = new Date(c.promisedPaymentDate);
           const now = new Date();
           promised.setHours(0,0,0,0);
           now.setHours(0,0,0,0);
           matchesFilter = promised <= now;
        } else {
          matchesFilter = false;
        }
      }

      return matchesSearch && matchesFilter;
    });
  }, [customers, searchTerm, filter]);

  const stats = useMemo(() => {
    const totalBalance = customers.reduce((acc, c) => acc + (c.balance || 0), 0);
    const totalCustomers = customers.length;
    // Apply conversion rate
    const convertedBalance = totalBalance * settings.conversionRate;
    return { totalBalance: convertedBalance, totalCustomers };
  }, [customers, settings.conversionRate]);

  const chartData = useMemo(() => {
    const limit = showTop10 ? 10 : 5;
    return [...customers]
      .sort((a, b) => b.balance - a.balance)
      .slice(0, limit)
      .map(c => ({
        name: c.name.split(' ')[0], 
        balance: c.balance * settings.conversionRate, // Convert for chart
        original: c
      }));
  }, [customers, showTop10, settings.conversionRate]);

  const getTodayCallStatus = (c: Customer) => {
    const today = new Date().toDateString();
    const todayLog = c.activityLogs?.find(l => 
      l.type === 'CALL' && new Date(l.timestamp).toDateString() === today
    );
    return todayLog;
  };

  const handleFullBackup = () => {
    const blob = generateBackup();
    const fileName = `SMA_GoogleDrive_Backup_${new Date().toISOString().slice(0,10)}.json`;
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert("Backup file ready! Please upload this .json file to your Google Drive for safe keeping.");
    setIsMenuOpen(false);
  };

  const handleCallReportExport = () => {
    if (customers.length === 0) {
      alert("No data to export");
      return;
    }
    exportCallReport(customers, activeSheet?.name || 'Call_Log');
    setIsMenuOpen(false);
  };

  const handleSmartSync = async () => {
    // If no new items, allow checking drive or just info
    if (pendingSyncCount === 0) {
      if (settings.driveFolderLink) {
         // If user has a drive link, offer to open it
         if (confirm("Sync is up to date. Open Cloud Drive folder?")) {
            window.open(settings.driveFolderLink, '_blank');
         }
      } else {
         alert("All caught up! No new updates to sync.");
      }
      return;
    }

    const success = await performSmartSync(settings);
    if (success) {
      // Ask user if they want to clear queue
      if (confirm("Sync shared/downloaded successfully! Clear pending queue?")) {
        clearSyncQueue();
        setPendingSyncCount(0);
      }
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20 relative">
      
      {/* Loading Overlay for Translation */}
      {isTranslating && (
        <div className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center text-white p-4">
          <div className="relative mb-4">
            <div className="w-20 h-20 border-4 border-gray-600 rounded-full"></div>
            <div className="absolute inset-0 w-20 h-20 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
               <span className="text-xs font-bold">{Math.round(translationProgress)}%</span>
            </div>
          </div>
          <h2 className="text-xl font-bold mb-1 flex items-center gap-2">
            {t.translating} <Sparkles size={18} className="text-purple-400 animate-pulse" />
          </h2>
          <p className="text-sm text-gray-300 mb-6 text-center max-w-xs">Converting data to Tamil safely. This takes time to ensure accuracy.</p>
          
          {/* Progress Bar */}
          <div className="w-full max-w-xs bg-gray-700 rounded-full h-2.5 overflow-hidden">
             <div className="bg-brand-500 h-2.5 rounded-full transition-all duration-300" style={{ width: `${translationProgress}%` }}></div>
          </div>
          <p className="text-xs text-gray-400 mt-2">Please do not close the app.</p>
        </div>
      )}
      
      {/* Side Menu Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
          <div className="relative bg-white w-4/5 max-w-xs h-full shadow-2xl flex flex-col animate-slide-in">
            {/* Menu Header with Global Stats */}
            <div className="p-6 bg-gradient-to-br from-slate-900 to-blue-900 text-white">
               <div className="flex justify-between items-center mb-6">
                 <h2 className="font-bold text-xl tracking-tight text-white/90">Menu</h2>
                 <button onClick={() => setIsMenuOpen(false)} className="p-1.5 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
                   <X size={20} className="text-white" />
                 </button>
               </div>
               
               {/* Total Accounts Summary Card (Global) */}
               <div className="bg-white/10 rounded-xl p-4 backdrop-blur-sm border border-white/10 shadow-inner">
                  <div className="flex items-center gap-2 text-blue-200 mb-2">
                      <DollarSign size={16} />
                      <span className="text-xs font-bold uppercase tracking-wider">Total Accounts</span>
                  </div>
                  <p className="text-2xl font-bold text-white mb-2 leading-none">
                      {settings.currencySymbol}{(globalStats.balance * settings.conversionRate).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-blue-200 bg-blue-800/50 inline-block px-2 py-1 rounded-md">
                      <Users size={12} />
                      <span className="font-medium">{globalStats.count} Customers (No.)</span>
                  </div>
               </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              
              {/* Added New Customer Button */}
              <button 
                onClick={() => { setIsMenuOpen(false); onAddNew(); }}
                className="w-full py-3 bg-brand-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-brand-700 shadow-md transition-all"
              >
                <Plus size={18} /> {t.newCustomer}
              </button>

              {/* Added Import Excel Button */}
              <button 
                onClick={() => { setIsMenuOpen(false); onImportClick(); }}
                className="w-full py-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gray-50 transition-all"
              >
                <FileSpreadsheet size={18} className="text-green-600" /> {t.importExcel}
              </button>

              <button
                  onClick={() => { setIsMenuOpen(false); onOpenSettings(); }}
                  className="w-full py-3 bg-gray-100 text-gray-800 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition-all"
                >
                  <Settings size={18} /> {t.settings}
              </button>

              <button 
                onClick={() => { setIsMenuOpen(false); setLanguage(language === 'en' ? 'ta' : 'en'); }}
                className="w-full py-3 bg-purple-50 text-purple-700 border border-purple-100 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-purple-100 transition-all"
              >
                 <Languages size={18} /> {language === 'en' ? 'தமிழ் (Tamil)' : 'English'}
              </button>
              
              <button 
                onClick={() => { setIsMenuOpen(false); exportToCSV(customers, activeSheet?.name || 'SMES_Customers'); }}
                className="w-full py-3 bg-gray-100 text-gray-800 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition-all"
              >
                <Download size={18} /> Export Customer List
              </button>

              {/* Report & Cloud Backup Section - Moved to Last */}
              <div className="bg-orange-50 rounded-xl p-3 border border-orange-100 mt-2 mb-2">
                  <h3 className="text-xs font-bold text-orange-800 mb-2 uppercase tracking-wide flex items-center gap-2">
                     <Cloud size={12} /> Reports & Cloud
                  </h3>
                  <button 
                    onClick={handleCallReportExport}
                    className="w-full py-2 bg-white text-orange-700 border border-orange-200 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-orange-100 mb-2 shadow-sm"
                  >
                    <Phone size={14} /> Export Call Report (CSV)
                  </button>
                  <button 
                    onClick={handleFullBackup}
                    className="w-full py-2 bg-orange-600 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-orange-700 shadow-md"
                  >
                    <UploadCloud size={14} /> Backup Whole App (Drive)
                  </button>
              </div>

            </div>
            
            <div className="p-4 border-t bg-gray-50 space-y-4">
               <button 
                 onClick={() => { setIsMenuOpen(false); onLogout(); }}
                 className="w-full py-2 text-red-500 font-bold flex items-center justify-center gap-2 hover:bg-red-50 rounded-lg transition-colors"
               >
                 <LogOut size={18} /> Logout
               </button>
               <div className="flex justify-between items-center text-xs text-gray-500">
                  <span>SMES Mobile Accounts</span>
                  <span>v1.7</span>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* Top Bar - Blue Gradient */}
      <div className="bg-gradient-to-br from-brand-600 to-brand-900 text-white px-6 pt-6 pb-12 rounded-b-[2.5rem] shadow-xl mb-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3 flex-1 overflow-hidden">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors shrink-0 backdrop-blur-sm border border-white/5"
            >
              <Menu size={24} />
            </button>
            <div className="flex-1 min-w-0">
              <h1 className="text-lg font-bold leading-tight truncate">{t.appTitle}</h1>
              <p className="text-blue-200 text-xs truncate opacity-70">{t.branchName}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             {/* Smart Sync Indicator */}
             <button 
               onClick={handleSmartSync}
               className={`p-2 rounded-full transition-all relative backdrop-blur-sm ${
                 pendingSyncCount > 0 
                   ? 'bg-orange-500 hover:bg-orange-400 text-white shadow-lg animate-pulse' 
                   : 'bg-white/10 hover:bg-white/20 text-blue-100 border border-white/5'
               }`}
               title={pendingSyncCount > 0 ? `${pendingSyncCount} Updates Pending` : "Sync Up to Date"}
             >
                <Cloud size={20} />
                {pendingSyncCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center border border-white">
                    {pendingSyncCount}
                  </span>
                )}
             </button>

             {/* Profile */}
             <button 
                onClick={onOpenTeamPerformance} 
                className="flex flex-col items-center justify-center pl-2 shrink-0 group"
              >
                 <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/10 flex items-center justify-center text-white overflow-hidden shadow-lg group-active:scale-95 transition-transform">
                    {user?.avatar ? (
                        <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                        <UserIcon size={20} />
                    )}
                 </div>
              </button>
          </div>
        </div>

        {/* Separated Stats Cards */}
        <div className="grid grid-cols-2 gap-4">
          {/* Balance Card */}
          <div className="bg-white/10 backdrop-blur-md border border-white/10 p-4 rounded-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
               <Wallet size={48} className="text-white" />
            </div>
            <div className="flex flex-col relative z-10">
               <span className="text-blue-200 text-[10px] font-bold uppercase tracking-widest mb-1">{t.totalDue}</span>
               <div className="text-xl font-bold text-white truncate">
                  {settings.currencySymbol}{stats.totalBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
               </div>
            </div>
          </div>

          {/* Customers Card */}
          <div className="bg-white/10 backdrop-blur-md border border-white/10 p-4 rounded-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
               <Users size={48} className="text-white" />
            </div>
            <div className="flex flex-col relative z-10">
               <span className="text-purple-200 text-[10px] font-bold uppercase tracking-widest mb-1">{t.customers}</span>
               <div className="text-xl font-bold text-white truncate">
                  {stats.totalCustomers}
               </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4">
        
        {/* Active Sheet Name - Modern Smart Box Design */}
        {activeSheet && (
           <div className="bg-white rounded-2xl p-4 shadow-lg border border-white/50 relative overflow-hidden mb-4 animate-scale-in bg-gradient-to-r from-white to-gray-50">
              <div className="absolute top-0 right-0 p-2 opacity-5">
                 <FileSpreadsheet size={64} className="text-brand-600" />
              </div>
              
              <div className="flex flex-col relative z-10">
                  <div className="flex justify-between items-center mb-1">
                     <span className="text-[10px] font-bold uppercase tracking-widest text-brand-600 bg-brand-50 px-2 py-0.5 rounded-md border border-brand-100">
                        Current Sheet
                     </span>
                     <span className="text-[10px] text-gray-400 font-mono">
                        {new Date(activeSheet.updatedAt).toLocaleDateString()}
                     </span>
                  </div>
                  
                  {/* The Single Line Name */}
                  <h2 className="text-2xl font-black text-gray-800 truncate leading-tight tracking-tight" title={activeSheet.name}>
                    {activeSheet.name}
                  </h2>
                  <p className="text-[10px] text-gray-400 mt-0.5 truncate">
                     {activeSheet.customerCount} Records • {settings.currencySymbol}{Math.round(activeSheet.totalBalance || 0).toLocaleString('en-IN')} Value
                  </p>
              </div>
           </div>
        )}

        {/* Modern Tech Grid Icons (Quick Actions) */}
        {activeSheet && (
          <div className="grid grid-cols-4 gap-2 mb-6 animate-slide-up">
            {/* Translate */}
            <button 
              onClick={onTranslateSheet}
              className="flex flex-col items-center gap-2 group"
            >
              <div className="w-14 h-14 rounded-2xl bg-white border border-purple-100 shadow-sm flex items-center justify-center text-purple-600 group-active:scale-95 transition-all shadow-purple-100/50 hover:shadow-purple-200">
                 <Sparkles size={24} className="group-hover:animate-pulse" />
              </div>
              <span className="text-[10px] font-bold text-gray-600 text-center leading-tight">Translate<br/>XL Sheet</span>
            </button>

            {/* Smart Stats */}
            <button 
              onClick={onOpenAnalytics}
              className="flex flex-col items-center gap-2 group"
            >
              <div className="w-14 h-14 rounded-2xl bg-white border border-indigo-100 shadow-sm flex items-center justify-center text-indigo-600 group-active:scale-95 transition-all shadow-indigo-100/50 hover:shadow-indigo-200">
                 <PieChart size={24} />
              </div>
              <span className="text-[10px] font-bold text-gray-600 text-center leading-tight">Smart<br/>Stats</span>
            </button>

            {/* Saved Accounts */}
            <button 
              onClick={onOpenSheetManager}
              className="flex flex-col items-center gap-2 group"
            >
              <div className="w-14 h-14 rounded-2xl bg-white border border-blue-100 shadow-sm flex items-center justify-center text-blue-600 group-active:scale-95 transition-all shadow-blue-100/50 hover:shadow-blue-200">
                 <FolderOpen size={24} />
              </div>
              <span className="text-[10px] font-bold text-gray-600 text-center leading-tight">Saved<br/>Accounts</span>
            </button>

             {/* Work History */}
            <button 
              onClick={onOpenHistory}
              className="flex flex-col items-center gap-2 group"
            >
              <div className="w-14 h-14 rounded-2xl bg-white border border-orange-100 shadow-sm flex items-center justify-center text-orange-600 group-active:scale-95 transition-all shadow-orange-100/50 hover:shadow-orange-200">
                 <History size={24} />
              </div>
              <span className="text-[10px] font-bold text-gray-600 text-center leading-tight">Work<br/>History</span>
            </button>
          </div>
        )}

        {/* Removed Action Buttons (Import/New Customer) from here */}

        {/* Chart Section (Only visible when filter is ALL or DEBT) */}
        {chartData.length > 0 && filter !== 'CONNECTED' && filter !== 'FAILED' && filter !== 'FOLLOW_UP' && (
          <div className="bg-white p-4 rounded-2xl shadow-sm mb-6 border border-gray-100 transition-all duration-300">
            <h3 className="text-sm font-bold text-gray-500 mb-4 flex items-center gap-2">
              <TrendingUp size={16} /> {t.topBalances}
            </h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} interval={0} />
                  <YAxis hide />
                  <Tooltip 
                    cursor={{fill: '#f0f9ff'}}
                    contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                    formatter={(value: number) => [`${settings.currencySymbol}${value.toLocaleString('en-IN', {maximumFractionDigits: 0})}`, t.balance]}
                  />
                  <Bar 
                    dataKey="balance" 
                    radius={[4, 4, 0, 0]} 
                    onClick={(data: any) => {
                      // Check direct property or payload (Recharts structure varies)
                      const customer = data.original || data.payload?.original;
                      if (customer) {
                        onSelectCustomer(customer);
                      }
                    }}
                    cursor="pointer"
                  >
                    {chartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={index === 0 ? '#ef4444' : '#0ea5e9'} 
                        className="hover:opacity-80 transition-opacity cursor-pointer"
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            {/* View Top 10 Toggle */}
            <div className="mt-4 pt-3 border-t border-gray-100 flex justify-center">
              <button 
                onClick={() => setShowTop10(!showTop10)}
                className="flex items-center gap-1 text-xs font-bold text-brand-600 hover:text-brand-800 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-full transition-colors"
              >
                {showTop10 ? (
                  <> {t.showLess} <ChevronUp size={14} /> </>
                ) : (
                  <> {t.viewTop10} <ChevronDown size={14} /> </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* List Header & Search & Filters */}
        <div className="flex flex-col gap-3 mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 text-gray-400" size={20} />
            <input 
              type="text" 
              placeholder={t.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white pl-10 pr-4 py-3 rounded-xl border-none shadow-sm focus:ring-2 focus:ring-brand-500 outline-none"
            />
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {/* Connected Button: Enhanced Green styling */}
            <button 
              onClick={() => setFilter('CONNECTED')}
              className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1 border shadow-sm ${
                filter === 'CONNECTED' 
                  ? 'bg-green-600 text-white border-green-600 shadow-green-200' 
                  : 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100'
              }`}
            >
              <CheckCircle size={14} className={filter === 'CONNECTED' ? 'text-white' : 'text-green-600'} /> 
              {t.filterConnected} 
              <span className={`ml-1 text-xs px-1.5 py-0.5 rounded-full ${filter === 'CONNECTED' ? 'bg-white/20' : 'bg-green-200/50'}`}>
                {counts.connected}
              </span>
            </button>
            
            {/* Failed Button: Enhanced Red styling with Smart Pulse */}
            <button 
              onClick={() => setFilter('FAILED')}
              className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1 border shadow-sm ${
                filter === 'FAILED' 
                  ? 'bg-red-600 text-white border-red-600 shadow-red-200' 
                  : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'
              } ${counts.failed > 0 && filter !== 'FAILED' ? 'animate-pulse ring-1 ring-red-300' : ''}`}
            >
              <PhoneMissed size={14} className={filter === 'FAILED' ? 'text-white' : 'text-red-600'} /> 
              {t.filterFailed} 
              <span className={`ml-1 text-xs px-1.5 py-0.5 rounded-full ${filter === 'FAILED' ? 'bg-white/20' : 'bg-red-200/50'}`}>
                {counts.failed}
              </span>
            </button>

            {/* Smart Follow-up Button: Golden Styling */}
            <button 
              onClick={() => setFilter('FOLLOW_UP')}
              className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1 border shadow-sm ${
                filter === 'FOLLOW_UP' 
                  ? 'bg-amber-500 text-white border-amber-600 shadow-amber-200' 
                  : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
              }`}
            >
              <BellRing size={14} className={filter === 'FOLLOW_UP' ? "text-white fill-white" : "text-amber-600 fill-amber-600"} /> 
              {t.filterFollowUp} 
              <span className={`ml-1 text-xs px-1.5 py-0.5 rounded-full ${filter === 'FOLLOW_UP' ? 'bg-white/20' : 'bg-amber-200/50'}`}>
                {counts.followUp}
              </span>
            </button>

            <button 
              onClick={() => setFilter('ALL')}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors border ${
                filter === 'ALL' 
                  ? 'bg-gray-800 text-white border-gray-800' 
                  : 'bg-white text-gray-600 border-gray-200'
              }`}
            >
              {t.allCustomers}
            </button>
            
            {/* Has Balance Button: Dark Red Styling */}
            <button 
              onClick={() => setFilter('DEBT')}
              className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-all border shadow-sm ${
                filter === 'DEBT' 
                  ? 'bg-red-900 text-white border-red-900 shadow-red-900/30' 
                  : 'bg-red-50 text-red-900 border-red-200 hover:bg-red-100'
              }`}
            >
              {t.hasBalance}
            </button>
          </div>
        </div>

        {filteredCustomers.length > 0 ? (
          <div className="space-y-3">
            {filteredCustomers.map((customer) => {
               // Calculate display items
               const todayStatus = getTodayCallStatus(customer);
               const isPriority = filter === 'FOLLOW_UP' || (customer.balance > 10000 && !todayStatus);

               return (
                <div 
                  key={customer.id} 
                  onClick={() => onSelectCustomer(customer)}
                  className={`bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center cursor-pointer transition-all active:scale-[0.98] ${
                    isPriority ? 'ring-1 ring-amber-100 border-amber-100' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 shrink-0">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 leading-tight">
                        {customer.name}
                        {customer.sNo && <span className="ml-1 text-[10px] text-gray-400 font-normal">#{customer.sNo}</span>}
                      </h3>
                      <div className="flex items-center gap-2 mt-0.5">
                         <span className="text-xs text-gray-500">{customer.itemTaken || 'No Item'}</span>
                         {/* Status Pill */}
                         {todayStatus && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase ${
                               todayStatus.callOutcome === 'CONNECTED' ? 'bg-green-100 text-green-700' :
                               todayStatus.callOutcome === 'DECLINED' ? 'bg-red-100 text-red-700' :
                               'bg-orange-100 text-orange-700'
                            }`}>
                               {todayStatus.callOutcome === 'CONNECTED' ? 'Called' : todayStatus.callOutcome}
                            </span>
                         )}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${customer.balance > 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {settings.currencySymbol}{(customer.balance * settings.conversionRate).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                    </p>
                    <p className="text-[10px] text-gray-400 mt-0.5">{formatDate(customer.date)}</p>
                  </div>
                </div>
               );
            })}
          </div>
        ) : (
          <div className="text-center py-10 text-gray-500">
            <p>{t.noCustomers}</p>
            {filter === 'ALL' && (
              <button onClick={onImportClick} className="mt-4 text-brand-600 font-bold hover:underline">
                {t.importPrompt}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};