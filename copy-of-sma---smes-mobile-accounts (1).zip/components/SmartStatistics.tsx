import React, { useMemo, useState } from 'react';
import { 
  ArrowLeft, Phone, Calendar, PieChart as PieChartIcon, 
  DollarSign, TrendingUp, Filter, PhoneIncoming, PhoneOff, 
  PhoneMissed, Layers, BarChart3, CreditCard, Users, User, Download 
} from 'lucide-react';
import { Customer, AppSettings } from '../types';
import { TranslationKeys } from '../constants/translations';
import { exportCallReport } from '../services/storageService';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, 
  XAxis, YAxis, Tooltip as ReTooltip, AreaChart, Area, 
  Legend, CartesianGrid 
} from 'recharts';

interface SmartStatisticsProps {
  customers: Customer[];
  onBack: () => void;
  t: TranslationKeys;
  settings: AppSettings;
  initialTab?: StatsTab;
}

export type StatsTab = 'CALLS' | 'PAYMENTS' | 'TEAM';
type TimeRange = 7 | 30 | 90;

export const SmartStatistics: React.FC<SmartStatisticsProps> = ({ customers, onBack, t, settings, initialTab = 'CALLS' }) => {
  const [activeTab, setActiveTab] = useState<StatsTab>(initialTab);
  const [days, setDays] = useState<TimeRange>(7);

  // --- Calculations ---

  const stats = useMemo(() => {
    let totalCalls = 0;
    let connected = 0;
    let declined = 0;
    let noAnswer = 0;
    let totalCollected = 0;

    const today = new Date();
    // Start date based on selected range (inclusive of today)
    const startDate = new Date();
    startDate.setDate(today.getDate() - days);
    startDate.setHours(0,0,0,0); // Start of that day

    // Daily buckets for chart
    const dailyDataMap = new Map<string, { date: string, calls: number, collection: number }>();
    
    // User Stats Map
    const userStatsMap = new Map<string, { 
      id: string, name: string, calls: number, connected: number, declined: number, noAnswer: number 
    }>();

    // Initialize buckets
    for(let i = days - 1; i >= 0; i--) {
       const d = new Date();
       d.setDate(d.getDate() - i);
       const dateKey = d.toDateString();
       dailyDataMap.set(dateKey, { 
         date: d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }), 
         calls: 0, 
         collection: 0 
       });
    }

    customers.forEach(c => {
       c.activityLogs?.forEach(log => {
          const logDate = new Date(log.timestamp);
          
          if (logDate >= startDate) {
             const dateKey = logDate.toDateString();
             const bucket = dailyDataMap.get(dateKey);

             if (log.type === 'CALL') {
                totalCalls++;
                if (bucket) bucket.calls++;

                // Global Counts
                if (log.callOutcome === 'CONNECTED') connected++;
                else if (log.callOutcome === 'DECLINED') declined++;
                else if (log.callOutcome === 'NO_ANSWER') noAnswer++;

                // --- User Specific Stats ---
                const uId = log.userId || 'unknown';
                const uName = log.userName || 'System/Legacy';
                
                if (!userStatsMap.has(uId)) {
                   userStatsMap.set(uId, { id: uId, name: uName, calls: 0, connected: 0, declined: 0, noAnswer: 0 });
                }
                const uStat = userStatsMap.get(uId)!;
                
                uStat.calls++;
                if (log.callOutcome === 'CONNECTED') uStat.connected++;
                else if (log.callOutcome === 'DECLINED') uStat.declined++;
                else if (log.callOutcome === 'NO_ANSWER') uStat.noAnswer++;
             }

             // Estimate Payment
             if ((log.type === 'UPDATE' || log.type === 'VOICE_UPDATE') && log.details.includes('Balance')) {
                 const match = log.details.match(/from (\d+(\.\d+)?) to (\d+(\.\d+)?)/);
                 if (match) {
                     const oldBal = parseFloat(match[1]);
                     const newBal = parseFloat(match[3]);
                     if (oldBal > newBal) {
                         const amount = oldBal - newBal;
                         totalCollected += amount;
                         if (bucket) bucket.collection += amount;
                     }
                 }
             }
          }
       });
    });

    const chartData = Array.from(dailyDataMap.values());
    const userStats = Array.from(userStatsMap.values()).sort((a,b) => b.calls - a.calls);

    return {
       totalCalls,
       connected,
       declined,
       noAnswer,
       totalCollected,
       chartData,
       userStats
    };
  }, [customers, days]);

  // Chart Data Preparation
  const pieData = [
      { name: t.connected, value: stats.connected, color: '#10b981' }, 
      { name: t.declined, value: stats.declined, color: '#ef4444' },   
      { name: t.noAnswer, value: stats.noAnswer, color: '#f97316' },   
  ].filter(d => d.value > 0);

  // Helper for Money
  const fmtMoney = (val: number) => {
     return (val * settings.conversionRate).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-10 flex flex-col">
      {/* 1. Modern Header */}
      <div className="bg-white sticky top-0 z-30 shadow-sm border-b border-gray-100">
        <div className="px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button 
              onClick={onBack} 
              className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-extrabold text-gray-800 tracking-tight flex items-center gap-2">
              <PieChartIcon className="text-brand-600" />
              {t.smartStatistics}
            </h1>
          </div>
          {/* Time Range Selector */}
          <div className="relative">
             <select 
               value={days}
               onChange={(e) => setDays(Number(e.target.value) as TimeRange)}
               className="appearance-none bg-gray-100 text-gray-700 font-bold text-xs py-2 pl-3 pr-8 rounded-lg border-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
             >
               <option value={7}>{t.range7Days}</option>
               <option value={30}>{t.range30Days}</option>
               <option value={90}>{t.range90Days}</option>
             </select>
             <Filter size={12} className="absolute right-2.5 top-2.5 text-gray-500 pointer-events-none" />
          </div>
        </div>

        {/* 2. Tab Switcher */}
        <div className="px-4 pb-2">
           <div className="bg-gray-100 p-1 rounded-xl flex gap-1">
              <button 
                 onClick={() => setActiveTab('CALLS')}
                 className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                   activeTab === 'CALLS' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                 }`}
              >
                 <Phone size={14} /> {t.statsCalls}
              </button>
              <button 
                 onClick={() => setActiveTab('PAYMENTS')}
                 className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                   activeTab === 'PAYMENTS' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                 }`}
              >
                 <DollarSign size={14} /> {t.statsPayments}
              </button>
              <button 
                 onClick={() => setActiveTab('TEAM')}
                 className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                   activeTab === 'TEAM' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                 }`}
              >
                 <Users size={14} /> {t.statsTeam}
              </button>
           </div>
        </div>
      </div>

      <div className="flex-1 p-4 space-y-6 animate-fade-in">
         
         {/* ============ CALLS VIEW ============ */}
         {activeTab === 'CALLS' && (
           <>
              {/* Scorecards */}
              <div className="grid grid-cols-2 gap-3">
                 <div className="bg-gradient-to-br from-blue-500 to-brand-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                    <div className="flex items-center gap-2 mb-2 opacity-90">
                       <PhoneIncoming size={18} />
                       <span className="text-xs font-bold uppercase">{t.callsMade}</span>
                    </div>
                    <div className="text-3xl font-extrabold">{stats.totalCalls}</div>
                    <div className="text-[10px] opacity-80 mt-1 font-medium">{t.avgDaily}: {Math.round(stats.totalCalls / days)}</div>
                 </div>
                 
                 <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-center">
                    <div className="flex items-center gap-2 text-green-600 mb-1">
                       <PieChartIcon size={18} />
                       <span className="text-xs font-bold uppercase">{t.callSuccessRate}</span>
                    </div>
                    <div className="text-2xl font-bold text-gray-800">
                      {stats.totalCalls > 0 ? Math.round((stats.connected / stats.totalCalls) * 100) : 0}%
                    </div>
                    <div className="w-full bg-gray-100 h-1.5 rounded-full mt-2 overflow-hidden">
                       <div className="bg-green-500 h-full rounded-full" style={{ width: `${stats.totalCalls > 0 ? (stats.connected / stats.totalCalls) * 100 : 0}%` }}></div>
                    </div>
                 </div>
              </div>

              {/* Pie Chart: Outcome Breakdown */}
              {stats.totalCalls > 0 ? (
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                   <div className="flex justify-between items-start mb-4">
                     <h3 className="font-bold text-gray-700 flex items-center gap-2 text-sm">
                        <Layers size={16} /> Outcome Breakdown
                     </h3>
                     <button 
                        onClick={() => exportCallReport(customers, 'Stats_Export')}
                        className="text-xs bg-brand-50 text-brand-700 px-3 py-1.5 rounded-full font-bold flex items-center gap-1 hover:bg-brand-100 transition-colors"
                     >
                        <Download size={12} /> CSV
                     </button>
                   </div>
                   <div className="flex items-center">
                      <div className="h-40 w-1/2">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                  data={pieData}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={40}
                                  outerRadius={60}
                                  paddingAngle={5}
                                  dataKey="value"
                                >
                                  {pieData.map((entry, index) => (
                                      <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                            </PieChart>
                          </ResponsiveContainer>
                      </div>
                      <div className="w-1/2 space-y-3 pl-2">
                          <div className="flex items-center justify-between">
                             <div className="flex items-center gap-1.5">
                                <div className="w-2.5 h-2.5 rounded-full bg-green-500"></div>
                                <span className="text-xs text-gray-600 font-bold">{t.connected}</span>
                             </div>
                             <span className="text-sm font-bold text-gray-800">{stats.connected}</span>
                          </div>
                          <div className="flex items-center justify-between">
                             <div className="flex items-center gap-1.5">
                                <div className="w-2.5 h-2.5 rounded-full bg-orange-500"></div>
                                <span className="text-xs text-gray-600 font-bold">{t.noAnswer}</span>
                             </div>
                             <span className="text-sm font-bold text-gray-800">{stats.noAnswer}</span>
                          </div>
                          <div className="flex items-center justify-between">
                             <div className="flex items-center gap-1.5">
                                <div className="w-2.5 h-2.5 rounded-full bg-red-500"></div>
                                <span className="text-xs text-gray-600 font-bold">{t.declined}</span>
                             </div>
                             <span className="text-sm font-bold text-gray-800">{stats.declined}</span>
                          </div>
                      </div>
                   </div>
                </div>
              ) : (
                <div className="bg-white p-8 rounded-2xl border border-gray-100 text-center text-gray-400">
                    <PhoneOff size={32} className="mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No calls recorded in this period</p>
                </div>
              )}

              {/* Bar Chart: Daily Volume */}
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2 text-sm">
                      <BarChart3 size={16} /> Daily Call Volume
                  </h3>
                  <div className="h-56 w-full text-xs">
                     <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={stats.chartData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                           <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10}} minTickGap={10} />
                           <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10}} allowDecimals={false} />
                           <ReTooltip 
                              cursor={{fill: '#eff6ff'}}
                              contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} 
                           />
                           <Bar dataKey="calls" name="Calls" radius={[4, 4, 0, 0]}>
                              {stats.chartData.map((entry, index) => (
                                 <Cell key={`cell-${index}`} fill="#3b82f6" />
                              ))}
                           </Bar>
                        </BarChart>
                     </ResponsiveContainer>
                  </div>
              </div>
           </>
         )}

         {/* ============ PAYMENTS VIEW ============ */}
         {activeTab === 'PAYMENTS' && (
           <>
              {/* Scorecard */}
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-6 rounded-3xl text-white shadow-xl shadow-emerald-100">
                 <div className="flex items-center gap-2 mb-2 opacity-90">
                    <CreditCard size={20} />
                    <span className="text-xs font-bold uppercase tracking-wider">{t.totalCollected}</span>
                 </div>
                 <div className="text-4xl font-extrabold flex items-baseline gap-1">
                    <span className="text-2xl opacity-80">{settings.currencySymbol}</span>
                    {fmtMoney(stats.totalCollected)}
                 </div>
                 <div className="mt-3 bg-white/20 inline-block px-3 py-1 rounded-lg text-xs font-medium backdrop-blur-sm">
                    {days} Days Period
                 </div>
              </div>

              {/* Area Chart: Collection Trend */}
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2 text-sm">
                      <TrendingUp size={16} /> {t.paymentTrend}
                  </h3>
                  <div className="h-64 w-full text-xs">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={stats.chartData} margin={{ top: 10, right: 0, left: -10, bottom: 0 }}>
                           <defs>
                              <linearGradient id="colorColl" x1="0" y1="0" x2="0" y2="1">
                                 <stop offset="5%" stopColor="#10b981" stopOpacity={0.6}/>
                                 <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                              </linearGradient>
                           </defs>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                           <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10}} minTickGap={15} />
                           <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10}} />
                           <ReTooltip 
                              formatter={(value: number) => [`${settings.currencySymbol}${fmtMoney(value)}`, t.collectedToday]}
                              contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} 
                           />
                           <Area 
                              type="monotone" 
                              dataKey="collection" 
                              stroke="#10b981" 
                              strokeWidth={3}
                              fillOpacity={1} 
                              fill="url(#colorColl)" 
                           />
                        </AreaChart>
                     </ResponsiveContainer>
                  </div>
              </div>

              {/* Mini Insight: Average Daily */}
              <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                       <Calendar size={18} />
                    </div>
                    <div>
                       <p className="text-xs font-bold text-emerald-800 uppercase">{t.avgDaily}</p>
                       <p className="text-xs text-emerald-600">Collection Pace</p>
                    </div>
                 </div>
                 <div className="text-xl font-bold text-emerald-700">
                    {settings.currencySymbol}{fmtMoney(stats.totalCollected / days)}
                 </div>
              </div>
           </>
         )}

         {/* ============ TEAM PERFORMANCE VIEW ============ */}
         {activeTab === 'TEAM' && (
            <div className="space-y-4">
               <div className="flex items-center justify-between">
                  <h3 className="font-bold text-gray-700 flex items-center gap-2">
                     <Users size={20} className="text-indigo-600"/> {t.agentPerformance}
                  </h3>
               </div>

               {/* New Feature: Individual User Statistics Graph */}
               {stats.userStats.length > 0 && (
                 <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 mb-2">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                       <BarChart3 size={12} /> Calls by User Name
                    </h4>
                    <div className="h-48 w-full text-xs">
                       <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={stats.userStats} layout="vertical" margin={{ top: 0, right: 30, left: 20, bottom: 0 }}>
                             <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f3f4f6" />
                             <XAxis type="number" hide />
                             <YAxis dataKey="name" type="category" width={80} tick={{fill: '#4b5563', fontSize: 10, fontWeight: 600}} axisLine={false} tickLine={false} />
                             <ReTooltip 
                                cursor={{fill: '#f0f9ff'}}
                                contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} 
                             />
                             <Bar dataKey="calls" name="Total Calls" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={20} />
                          </BarChart>
                       </ResponsiveContainer>
                    </div>
                 </div>
               )}

               {stats.userStats.length === 0 ? (
                  <div className="bg-white p-8 rounded-2xl border border-gray-100 text-center text-gray-400">
                     <User size={32} className="mx-auto mb-2 opacity-30" />
                     <p className="text-sm">No agent activity recorded in this period</p>
                  </div>
               ) : (
                  stats.userStats.map((u) => {
                     const successRate = u.calls > 0 ? Math.round((u.connected / u.calls) * 100) : 0;
                     return (
                        <div key={u.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm relative overflow-hidden">
                           {/* Agent Header */}
                           <div className="flex items-center gap-3 mb-3 relative z-10">
                              <div className="w-10 h-10 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm">
                                 {u.name.charAt(0).toUpperCase()}
                              </div>
                              <div className="flex-1">
                                 <h4 className="font-bold text-gray-900 leading-tight">{u.name}</h4>
                                 <p className="text-xs text-gray-500">{u.calls} Calls Made</p>
                              </div>
                              <div className="text-right">
                                 <div className="text-xl font-bold text-gray-800">{successRate}%</div>
                                 <div className="text-[10px] font-bold text-gray-400 uppercase">{t.successRate}</div>
                              </div>
                           </div>

                           {/* Progress Bar */}
                           <div className="h-1.5 w-full bg-gray-100 rounded-full mb-4 overflow-hidden">
                              <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: `${successRate}%` }}></div>
                           </div>

                           {/* Stats Grid */}
                           <div className="grid grid-cols-3 gap-2">
                              <div className="bg-green-50 p-2 rounded-lg text-center border border-green-100">
                                 <div className="text-lg font-bold text-green-700">{u.connected}</div>
                                 <div className="text-[10px] font-bold text-green-600 uppercase flex items-center justify-center gap-1">
                                    <PhoneIncoming size={10} /> {t.connected}
                                 </div>
                              </div>
                              <div className="bg-orange-50 p-2 rounded-lg text-center border border-orange-100">
                                 <div className="text-lg font-bold text-orange-700">{u.noAnswer}</div>
                                 <div className="text-[10px] font-bold text-orange-600 uppercase flex items-center justify-center gap-1">
                                    <PhoneMissed size={10} /> {t.noAnswer}
                                 </div>
                              </div>
                              <div className="bg-red-50 p-2 rounded-lg text-center border border-red-100">
                                 <div className="text-lg font-bold text-red-700">{u.declined}</div>
                                 <div className="text-[10px] font-bold text-red-600 uppercase flex items-center justify-center gap-1">
                                    <PhoneOff size={10} /> {t.declined}
                                 </div>
                              </div>
                           </div>
                        </div>
                     );
                  })
               )}
            </div>
         )}

      </div>
    </div>
  );
};